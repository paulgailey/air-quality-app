"use strict";
/**
 * 🔐 TpaToken Types Module
 *
 * Defines types for the TPA token authentication mechanism.
 */
Object.defineProperty(exports, "__esModule", { value: true });
