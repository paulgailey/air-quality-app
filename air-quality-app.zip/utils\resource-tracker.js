"use strict";
/**
 * Resource Tracker
 *
 * A utility class for tracking and automatically cleaning up resources
 * like timers, event listeners, and other disposable objects.
 *
 * This helps prevent memory leaks by ensuring that all resources are
 * properly disposed when they're no longer needed.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceTracker = void 0;
exports.createResourceTracker = createResourceTracker;
/**
 * Manages resources to prevent memory leaks
 */
class ResourceTracker {
    constructor() {
        // Collection of cleanup functions to call when dispose() is called
        this.cleanupFunctions = [];
        // Flag to track if this resource tracker has been disposed
        this.isDisposed = false;
    }
    /**
     * Add a cleanup function to be executed when dispose() is called
     *
     * @param cleanup - The cleanup function to register
     * @returns A function that will remove this cleanup function
     */
    track(cleanup) {
        if (this.isDisposed) {
            throw new Error('Cannot track resources on a disposed ResourceTracker');
        }
        this.cleanupFunctions.push(cleanup);
        // Return a function that will remove this cleanup function
        return () => {
            const index = this.cleanupFunctions.indexOf(cleanup);
            if (index !== -1) {
                this.cleanupFunctions.splice(index, 1);
            }
        };
    }
    /**
     * Track a disposable object (anything with a dispose or close method)
     *
     * @param disposable - The object to track
     * @returns A function that will remove this disposable
     */
    trackDisposable(disposable) {
        return this.track(() => {
            if (typeof disposable.dispose === 'function') {
                disposable.dispose();
            }
            else if (typeof disposable.close === 'function') {
                disposable.close();
            }
        });
    }
    /**
     * Track a timer and ensure it gets cleared
     *
     * @param timerId - The timer ID to track
     * @param isInterval - Whether this is an interval (true) or timeout (false)
     * @returns A function that will remove this timer
     */
    trackTimer(timerId, isInterval = false) {
        return this.track(() => {
            if (isInterval) {
                clearInterval(timerId);
            }
            else {
                clearTimeout(timerId);
            }
        });
    }
    /**
     * Track a timeout and ensure it gets cleared
     *
     * @param timerId - The timeout ID to track
     * @returns A function that will remove this timeout
     */
    trackTimeout(timerId) {
        return this.trackTimer(timerId, false);
    }
    /**
     * Track an interval and ensure it gets cleared
     *
     * @param timerId - The interval ID to track
     * @returns A function that will remove this interval
     */
    trackInterval(timerId) {
        return this.trackTimer(timerId, true);
    }
    /**
     * Create a tracked timeout
     *
     * @param callback - Function to call when the timeout expires
     * @param ms - Milliseconds to wait
     * @returns The timeout ID
     */
    setTimeout(callback, ms) {
        const timerId = setTimeout(callback, ms);
        this.trackTimeout(timerId);
        return timerId;
    }
    /**
     * Create a tracked interval
     *
     * @param callback - Function to call at each interval
     * @param ms - Milliseconds between intervals
     * @returns The interval ID
     */
    setInterval(callback, ms) {
        const timerId = setInterval(callback, ms);
        this.trackInterval(timerId);
        return timerId;
    }
    /**
     * Dispose of all tracked resources
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        // Run all cleanup functions
        for (const cleanup of this.cleanupFunctions) {
            try {
                cleanup();
            }
            catch (error) {
                console.error('Error during resource cleanup:', error);
            }
        }
        // Clear the array
        this.cleanupFunctions = [];
        this.isDisposed = true;
    }
    /**
     * Check if this tracker has been disposed
     */
    get disposed() {
        return this.isDisposed;
    }
}
exports.ResourceTracker = ResourceTracker;
/**
 * Create a new ResourceTracker instance
 *
 * @returns A new ResourceTracker
 */
function createResourceTracker() {
    return new ResourceTracker();
}
