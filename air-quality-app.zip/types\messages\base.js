"use strict";
// src/messages/base.ts
Object.defineProperty(exports, "__esModule", { value: true });
