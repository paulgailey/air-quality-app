"use strict";
// src/message-types.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardMessageTypes = exports.UpdateTypes = exports.ResponseTypes = exports.EventTypes = exports.ControlActionTypes = exports.CloudToTpaMessageType = exports.TpaToCloudMessageType = exports.CloudToGlassesMessageType = exports.GlassesToCloudMessageType = void 0;
/**
 * Types of messages from glasses to cloud
 */
var GlassesToCloudMessageType;
(function (GlassesToCloudMessageType) {
    // Control actions
    GlassesToCloudMessageType["CONNECTION_INIT"] = "connection_init";
    GlassesToCloudMessageType["REQUEST_SETTINGS"] = "request_settings";
    // START_APP = 'start_app',
    // STOP_APP = 'stop_app',
    GlassesToCloudMessageType["START_APP"] = "start_app";
    GlassesToCloudMessageType["STOP_APP"] = "stop_app";
    GlassesToCloudMessageType["DASHBOARD_STATE"] = "dashboard_state";
    GlassesToCloudMessageType["OPEN_DASHBOARD"] = "open_dashboard";
    // Mentra Live
    GlassesToCloudMessageType["PHOTO_RESPONSE"] = "photo_response";
    GlassesToCloudMessageType["VIDEO_STREAM_RESPONSE"] = "video_stream_response";
    // photo_response = 'photo_response',
    // video_stream_response = 'video_stream_response',
    // OPEN_DASHBOARD = 'open_dashboard',
    // Events and data
    // BUTTON_PRESS = 'button_press',
    // HEAD_POSITION = 'head_position',
    // GLASSES_BATTERY_UPDATE = 'glasses_battery_update',
    // PHONE_BATTERY_UPDATE = 'phone_battery_update',
    // GLASSES_CONNECTION_STATE = 'glasses_connection_state',
    // LOCATION_UPDATE = 'location_update',
    // PHONE_NOTIFICATION = 'phone_notification',
    // NOTIFICATION_DISMISSED = 'notification_dismissed'
    GlassesToCloudMessageType["BUTTON_PRESS"] = "button_press";
    GlassesToCloudMessageType["HEAD_POSITION"] = "head_position";
    GlassesToCloudMessageType["GLASSES_BATTERY_UPDATE"] = "glasses_battery_update";
    GlassesToCloudMessageType["PHONE_BATTERY_UPDATE"] = "phone_battery_update";
    GlassesToCloudMessageType["GLASSES_CONNECTION_STATE"] = "glasses_connection_state";
    GlassesToCloudMessageType["LOCATION_UPDATE"] = "location_update";
    GlassesToCloudMessageType["VAD"] = "VAD";
    GlassesToCloudMessageType["PHONE_NOTIFICATION"] = "phone_notification";
    GlassesToCloudMessageType["NOTIFICATION_DISMISSED"] = "notification_dismissed";
    GlassesToCloudMessageType["CALENDAR_EVENT"] = "calendar_event";
    GlassesToCloudMessageType["AUGMENTOS_SETTINGS_UPDATE_REQUEST"] = "settings_update_request";
    GlassesToCloudMessageType["CORE_STATUS_UPDATE"] = "core_status_update";
})(GlassesToCloudMessageType || (exports.GlassesToCloudMessageType = GlassesToCloudMessageType = {}));
/**
 * Types of messages from cloud to glasses
 */
var CloudToGlassesMessageType;
(function (CloudToGlassesMessageType) {
    // Responses
    CloudToGlassesMessageType["CONNECTION_ACK"] = "connection_ack";
    CloudToGlassesMessageType["CONNECTION_ERROR"] = "connection_error";
    CloudToGlassesMessageType["AUTH_ERROR"] = "auth_error";
    // Updates
    CloudToGlassesMessageType["DISPLAY_EVENT"] = "display_event";
    CloudToGlassesMessageType["APP_STATE_CHANGE"] = "app_state_change";
    CloudToGlassesMessageType["MICROPHONE_STATE_CHANGE"] = "microphone_state_change";
    CloudToGlassesMessageType["PHOTO_REQUEST"] = "photo_request";
    CloudToGlassesMessageType["VIDEO_STREAM_REQUEST"] = "video_stream_request";
    CloudToGlassesMessageType["SETTINGS_UPDATE"] = "settings_update";
    // Dashboard updates
    CloudToGlassesMessageType["DASHBOARD_MODE_CHANGE"] = "dashboard_mode_change";
    CloudToGlassesMessageType["DASHBOARD_ALWAYS_ON_CHANGE"] = "dashboard_always_on_change";
    CloudToGlassesMessageType["WEBSOCKET_ERROR"] = "websocket_error";
})(CloudToGlassesMessageType || (exports.CloudToGlassesMessageType = CloudToGlassesMessageType = {}));
/**
 * Types of messages from TPAs to cloud
 */
var TpaToCloudMessageType;
(function (TpaToCloudMessageType) {
    // Commands
    TpaToCloudMessageType["CONNECTION_INIT"] = "tpa_connection_init";
    TpaToCloudMessageType["SUBSCRIPTION_UPDATE"] = "subscription_update";
    // Requests
    TpaToCloudMessageType["DISPLAY_REQUEST"] = "display_event";
    TpaToCloudMessageType["PHOTO_REQUEST"] = "photo_request";
    TpaToCloudMessageType["VIDEO_STREAM_REQUEST"] = "video_stream_request";
    // Dashboard requests
    TpaToCloudMessageType["DASHBOARD_CONTENT_UPDATE"] = "dashboard_content_update";
    TpaToCloudMessageType["DASHBOARD_MODE_CHANGE"] = "dashboard_mode_change";
    TpaToCloudMessageType["DASHBOARD_SYSTEM_UPDATE"] = "dashboard_system_update";
})(TpaToCloudMessageType || (exports.TpaToCloudMessageType = TpaToCloudMessageType = {}));
/**
 * Types of messages from cloud to TPAs
 */
var CloudToTpaMessageType;
(function (CloudToTpaMessageType) {
    // Responses
    CloudToTpaMessageType["CONNECTION_ACK"] = "tpa_connection_ack";
    CloudToTpaMessageType["CONNECTION_ERROR"] = "tpa_connection_error";
    // Updates
    CloudToTpaMessageType["APP_STOPPED"] = "app_stopped";
    CloudToTpaMessageType["SETTINGS_UPDATE"] = "settings_update";
    // Dashboard updates
    CloudToTpaMessageType["DASHBOARD_MODE_CHANGED"] = "dashboard_mode_changed";
    CloudToTpaMessageType["DASHBOARD_ALWAYS_ON_CHANGED"] = "dashboard_always_on_changed";
    // Stream data
    CloudToTpaMessageType["DATA_STREAM"] = "data_stream";
    // Media responses
    CloudToTpaMessageType["PHOTO_RESPONSE"] = "photo_response";
    CloudToTpaMessageType["VIDEO_STREAM_RESPONSE"] = "video_stream_response";
    CloudToTpaMessageType["WEBSOCKET_ERROR"] = "websocket_error";
    // General purpose messaging
    CloudToTpaMessageType["CUSTOM_MESSAGE"] = "custom_message";
})(CloudToTpaMessageType || (exports.CloudToTpaMessageType = CloudToTpaMessageType = {}));
/**
 * Control action message types (subset of GlassesToCloudMessageType)
 */
exports.ControlActionTypes = [
    GlassesToCloudMessageType.CONNECTION_INIT,
    GlassesToCloudMessageType.START_APP,
    GlassesToCloudMessageType.STOP_APP,
    GlassesToCloudMessageType.DASHBOARD_STATE,
    GlassesToCloudMessageType.OPEN_DASHBOARD
];
/**
 * Event message types (subset of GlassesToCloudMessageType)
 */
exports.EventTypes = [
    GlassesToCloudMessageType.BUTTON_PRESS,
    GlassesToCloudMessageType.HEAD_POSITION,
    GlassesToCloudMessageType.GLASSES_BATTERY_UPDATE,
    GlassesToCloudMessageType.PHONE_BATTERY_UPDATE,
    GlassesToCloudMessageType.GLASSES_CONNECTION_STATE,
    GlassesToCloudMessageType.LOCATION_UPDATE,
    GlassesToCloudMessageType.VAD,
    GlassesToCloudMessageType.PHONE_NOTIFICATION,
    GlassesToCloudMessageType.NOTIFICATION_DISMISSED,
    GlassesToCloudMessageType.CALENDAR_EVENT,
    GlassesToCloudMessageType.AUGMENTOS_SETTINGS_UPDATE_REQUEST,
    GlassesToCloudMessageType.CORE_STATUS_UPDATE
];
/**
 * Response message types (subset of CloudToGlassesMessageType)
 */
exports.ResponseTypes = [
    CloudToGlassesMessageType.CONNECTION_ACK,
    CloudToGlassesMessageType.CONNECTION_ERROR,
    CloudToGlassesMessageType.AUTH_ERROR
];
/**
 * Update message types (subset of CloudToGlassesMessageType)
 */
exports.UpdateTypes = [
    CloudToGlassesMessageType.DISPLAY_EVENT,
    CloudToGlassesMessageType.APP_STATE_CHANGE,
    CloudToGlassesMessageType.MICROPHONE_STATE_CHANGE,
    CloudToGlassesMessageType.PHOTO_REQUEST,
    CloudToGlassesMessageType.VIDEO_STREAM_REQUEST,
    CloudToGlassesMessageType.SETTINGS_UPDATE,
    CloudToGlassesMessageType.DASHBOARD_MODE_CHANGE,
    CloudToGlassesMessageType.DASHBOARD_ALWAYS_ON_CHANGE
];
/**
 * Dashboard message types
 */
exports.DashboardMessageTypes = [
    TpaToCloudMessageType.DASHBOARD_CONTENT_UPDATE,
    TpaToCloudMessageType.DASHBOARD_MODE_CHANGE,
    TpaToCloudMessageType.DASHBOARD_SYSTEM_UPDATE,
    CloudToTpaMessageType.DASHBOARD_MODE_CHANGED,
    CloudToTpaMessageType.DASHBOARD_ALWAYS_ON_CHANGED
];
