/**
 * 🎮 Event Manager Module
 */
import EventEmitter from 'events';
import { StreamType, ExtendedStreamType, AppSettings, WebSocketError, ButtonPress, HeadPosition, PhoneNotification, TranscriptionData, TranslationData, GlassesBatteryUpdate, PhoneBatteryUpdate, GlassesConnectionState, LocationUpdate, Vad, NotificationDismissed, AudioChunk, CalendarEvent, CustomMessage } from '../../types';
import { DashboardMode } from '../../types/dashboard';
/** 🎯 Type-safe event handler function */
type Handler<T> = (data: T) => void;
/** 🔄 System events not tied to streams */
interface SystemEvents {
    'connected': AppSettings | undefined;
    'disconnected': string | {
        message: string;
        code: number;
        reason: string;
        wasClean: boolean;
        permanent?: boolean;
    };
    'error': WebSocketError | Error;
    'settings_update': AppSettings;
    'dashboard_mode_change': {
        mode: DashboardMode | 'none';
    };
    'dashboard_always_on_change': {
        enabled: boolean;
    };
    'custom_message': CustomMessage;
}
/** 📡 All possible event types */
type EventType = ExtendedStreamType | keyof SystemEvents;
/** 📦 Map of stream types to their data types */
export interface StreamDataTypes {
    [StreamType.BUTTON_PRESS]: ButtonPress;
    [StreamType.HEAD_POSITION]: HeadPosition;
    [StreamType.PHONE_NOTIFICATION]: PhoneNotification;
    [StreamType.TRANSCRIPTION]: TranscriptionData;
    [StreamType.TRANSLATION]: TranslationData;
    [StreamType.GLASSES_BATTERY_UPDATE]: GlassesBatteryUpdate;
    [StreamType.PHONE_BATTERY_UPDATE]: PhoneBatteryUpdate;
    [StreamType.GLASSES_CONNECTION_STATE]: GlassesConnectionState;
    [StreamType.LOCATION_UPDATE]: LocationUpdate;
    [StreamType.CALENDAR_EVENT]: CalendarEvent;
    [StreamType.VAD]: Vad;
    [StreamType.NOTIFICATION_DISMISSED]: NotificationDismissed;
    [StreamType.AUDIO_CHUNK]: AudioChunk;
    [StreamType.VIDEO]: ArrayBuffer;
    [StreamType.OPEN_DASHBOARD]: never;
    [StreamType.START_APP]: never;
    [StreamType.STOP_APP]: never;
    [StreamType.ALL]: never;
    [StreamType.WILDCARD]: never;
}
/** 📦 Data type for an event */
export type EventData<T extends EventType> = T extends keyof StreamDataTypes ? StreamDataTypes[T] : T extends keyof SystemEvents ? SystemEvents[T] : T extends string ? T extends `${StreamType.TRANSCRIPTION}:${string}` ? TranscriptionData : T extends `${StreamType.TRANSLATION}:${string}` ? TranslationData : never : never;
export declare class EventManager {
    private subscribe;
    private unsubscribe;
    private emitter;
    private handlers;
    private lastLanguageTranscriptioCleanupHandler;
    private lastLanguageTranslationCleanupHandler;
    constructor(subscribe: (type: ExtendedStreamType) => void, unsubscribe: (type: ExtendedStreamType) => void);
    onTranscription(handler: Handler<TranscriptionData>): () => void;
    /**
     * 🎤 Listen for transcription events in a specific language
     * @param language - Language code (e.g., "en-US")
     * @param handler - Function to handle transcription data
     * @returns Cleanup function to remove the handler
     * @throws Error if language code is invalid
     */
    onTranscriptionForLanguage(language: string, handler: Handler<TranscriptionData>): () => void;
    /**
     * 🌐 Listen for translation events for a specific language pair
     * @param sourceLanguage - Source language code (e.g., "es-ES")
     * @param targetLanguage - Target language code (e.g., "en-US")
     * @param handler - Function to handle translation data
     * @returns Cleanup function to remove the handler
     * @throws Error if language codes are invalid
     */
    ontranslationForLanguage(sourceLanguage: string, targetLanguage: string, handler: Handler<TranslationData>): () => void;
    onHeadPosition(handler: Handler<HeadPosition>): () => void;
    onButtonPress(handler: Handler<ButtonPress>): () => void;
    onPhoneNotifications(handler: Handler<PhoneNotification>): () => void;
    onGlassesBattery(handler: Handler<GlassesBatteryUpdate>): () => void;
    onPhoneBattery(handler: Handler<PhoneBatteryUpdate>): () => void;
    onVoiceActivity(handler: Handler<Vad>): () => void;
    onLocation(handler: Handler<LocationUpdate>): () => void;
    onCalendarEvent(handler: Handler<CalendarEvent>): () => void;
    /**
     * 🎤 Listen for audio chunk data
     * @param handler - Function to handle audio chunks
     * @returns Cleanup function to remove the handler
     */
    onAudioChunk(handler: Handler<AudioChunk>): () => void;
    onConnected(handler: Handler<SystemEvents['connected']>): () => EventEmitter<[never]>;
    onDisconnected(handler: Handler<SystemEvents['disconnected']>): () => EventEmitter<[never]>;
    onError(handler: Handler<SystemEvents['error']>): () => EventEmitter<[never]>;
    onSettingsUpdate(handler: Handler<SystemEvents['settings_update']>): () => EventEmitter<[never]>;
    /**
     * 🌐 Listen for dashboard mode changes
     * @param handler - Function to handle dashboard mode changes
     * @returns Cleanup function to remove the handler
     */
    onDashboardModeChange(handler: Handler<SystemEvents['dashboard_mode_change']>): () => EventEmitter<[never]>;
    /**
     * 🌐 Listen for dashboard always-on mode changes
     * @param handler - Function to handle dashboard always-on mode changes
     * @returns Cleanup function to remove the handler
     */
    onDashboardAlwaysOnChange(handler: Handler<SystemEvents['dashboard_always_on_change']>): () => EventEmitter<[never]>;
    /**
     * 🔄 Listen for changes to a specific setting
     * @param key - Setting key to monitor
     * @param handler - Function to handle setting value changes
     * @returns Cleanup function to remove the handler
     */
    onSettingChange<T>(key: string, handler: (value: T, previousValue: T | undefined) => void): () => void;
    /**
     * 🔄 Generic event handler
     *
     * Use this for stream types without specific handler methods
     */
    on<T extends ExtendedStreamType>(type: T, handler: Handler<EventData<T>>): () => void;
    /**
     * ➕ Add an event handler and subscribe if needed
     */
    private addHandler;
    /**
     * ➖ Remove an event handler
     */
    private removeHandler;
    /**
     * 📡 Emit an event to all registered handlers with error isolation
     */
    emit<T extends EventType>(event: T, data: EventData<T>): void;
    /**
     * 📨 Listen for custom messages with a specific action
     * @param action - The action identifier to filter by
     * @param handler - Function to handle the message
     * @returns Cleanup function to remove the handler
     */
    onCustomMessage(action: string, handler: (payload: any) => void): () => void;
}
export {};
//# sourceMappingURL=events.d.ts.map