"use strict";
/**
 * Constants for the SDK
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.systemApps = void 0;
/**
 * System app definitions
 */
exports.systemApps = {
    dashboard: {
        name: 'Dashboard',
        packageName: 'system.augmentos.dashboard',
        isSystemApp: true
    },
    captions: {
        name: 'Live Captions',
        packageName: 'system.augmentos.livecaptions',
        isSystemApp: true
    },
    notifications: {
        name: 'Notifications',
        packageName: 'system.augmentos.notifications',
        isSystemApp: true
    }
};
