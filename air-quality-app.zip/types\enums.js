"use strict";
// src/enums.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppSettingType = exports.ViewType = exports.LayoutType = exports.Language = exports.AppState = exports.TpaType = void 0;
/**
 * Types of Third-Party Applications (TPAs)
 */
var TpaType;
(function (TpaType) {
    TpaType["SYSTEM_DASHBOARD"] = "system_dashboard";
    TpaType["BACKGROUND"] = "background";
    TpaType["STANDARD"] = "standard"; // Regular TPA (default) only one standard app can run at a time. starting a standard TPA will close any other standard TPA that is running.
})(TpaType || (exports.TpaType = TpaType = {}));
/**
 * Application states in the system
 */
var AppState;
(function (AppState) {
    AppState["NOT_INSTALLED"] = "not_installed";
    AppState["INSTALLED"] = "installed";
    AppState["BOOTING"] = "booting";
    AppState["RUNNING"] = "running";
    AppState["STOPPED"] = "stopped";
    AppState["ERROR"] = "error"; // Error state
})(AppState || (exports.AppState = AppState = {}));
/**
 * Supported languages
 */
var Language;
(function (Language) {
    Language["EN"] = "en";
    Language["ES"] = "es";
    Language["FR"] = "fr";
    // TODO: Add more languages
})(Language || (exports.Language = Language = {}));
/**
 * Types of layouts for displaying content
 */
var LayoutType;
(function (LayoutType) {
    LayoutType["TEXT_WALL"] = "text_wall";
    LayoutType["DOUBLE_TEXT_WALL"] = "double_text_wall";
    LayoutType["DASHBOARD_CARD"] = "dashboard_card";
    LayoutType["REFERENCE_CARD"] = "reference_card";
    LayoutType["BITMAP_VIEW"] = "bitmap_view";
})(LayoutType || (exports.LayoutType = LayoutType = {}));
/**
 * Types of views for displaying content
 */
var ViewType;
(function (ViewType) {
    ViewType["DASHBOARD"] = "dashboard";
    ViewType["ALWAYS_ON"] = "always_on";
    ViewType["MAIN"] = "main"; // Regular app content
})(ViewType || (exports.ViewType = ViewType = {}));
// Types for AppSettings
var AppSettingType;
(function (AppSettingType) {
    AppSettingType["TOGGLE"] = "toggle";
    AppSettingType["TEXT"] = "text";
    AppSettingType["SELECT"] = "select";
})(AppSettingType || (exports.AppSettingType = AppSettingType = {}));
// | { type: "toggle"; key: string; label: string; defaultValue: boolean }
// | { type: "text"; key: string; label: string; defaultValue?: string }
// | { type: "select"; key: string; label: string; options: { label: string; value: string }[]; defaultValue?: string };
