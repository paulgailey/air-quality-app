/**
 * 🔐 TPA Token Module
 *
 * Provides utilities for working with TPA tokens.
 */
export * from './utils';
//# sourceMappingURL=index.d.ts.map