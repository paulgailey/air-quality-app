"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventManager = void 0;
/**
 * 🎮 Event Manager Module
 */
const events_1 = __importDefault(require("events"));
const types_1 = require("../../types");
class EventManager {
    constructor(subscribe, unsubscribe) {
        this.subscribe = subscribe;
        this.unsubscribe = unsubscribe;
        this.emitter = new events_1.default();
        this.handlers = new Map();
        this.lastLanguageTranscriptioCleanupHandler = () => { };
        this.lastLanguageTranslationCleanupHandler = () => { };
    }
    // Convenience handlers for common event types
    onTranscription(handler) {
        // Default to en-US when using the generic transcription handler
        return this.addHandler((0, types_1.createTranscriptionStream)('en-US'), handler);
    }
    /**
     * 🎤 Listen for transcription events in a specific language
     * @param language - Language code (e.g., "en-US")
     * @param handler - Function to handle transcription data
     * @returns Cleanup function to remove the handler
     * @throws Error if language code is invalid
     */
    onTranscriptionForLanguage(language, handler) {
        if (!(0, types_1.isValidLanguageCode)(language)) {
            throw new Error(`Invalid language code: ${language}`);
        }
        this.lastLanguageTranscriptioCleanupHandler();
        // console.log(`((())) onTranscriptionForLanguage: ${language}`);
        const streamType = (0, types_1.createTranscriptionStream)(language);
        // console.log(`((())) streamType: ${streamType}`);
        // console.log(`^^^^^^^ handler: ${handler.toString()}`);
        this.lastLanguageTranscriptioCleanupHandler = this.addHandler(streamType, handler);
        return this.lastLanguageTranscriptioCleanupHandler;
    }
    /**
     * 🌐 Listen for translation events for a specific language pair
     * @param sourceLanguage - Source language code (e.g., "es-ES")
     * @param targetLanguage - Target language code (e.g., "en-US")
     * @param handler - Function to handle translation data
     * @returns Cleanup function to remove the handler
     * @throws Error if language codes are invalid
     */
    ontranslationForLanguage(sourceLanguage, targetLanguage, handler) {
        if (!(0, types_1.isValidLanguageCode)(sourceLanguage)) {
            throw new Error(`Invalid source language code: ${sourceLanguage}`);
        }
        if (!(0, types_1.isValidLanguageCode)(targetLanguage)) {
            throw new Error(`Invalid target language code: ${targetLanguage}`);
        }
        this.lastLanguageTranslationCleanupHandler();
        const streamType = (0, types_1.createTranslationStream)(sourceLanguage, targetLanguage);
        this.lastLanguageTranslationCleanupHandler = this.addHandler(streamType, handler);
        return this.lastLanguageTranslationCleanupHandler;
    }
    onHeadPosition(handler) {
        return this.addHandler(types_1.StreamType.HEAD_POSITION, handler);
    }
    onButtonPress(handler) {
        return this.addHandler(types_1.StreamType.BUTTON_PRESS, handler);
    }
    onPhoneNotifications(handler) {
        return this.addHandler(types_1.StreamType.PHONE_NOTIFICATION, handler);
    }
    onGlassesBattery(handler) {
        return this.addHandler(types_1.StreamType.GLASSES_BATTERY_UPDATE, handler);
    }
    onPhoneBattery(handler) {
        return this.addHandler(types_1.StreamType.PHONE_BATTERY_UPDATE, handler);
    }
    onVoiceActivity(handler) {
        return this.addHandler(types_1.StreamType.VAD, handler);
    }
    onLocation(handler) {
        return this.addHandler(types_1.StreamType.LOCATION_UPDATE, handler);
    }
    onCalendarEvent(handler) {
        return this.addHandler(types_1.StreamType.CALENDAR_EVENT, handler);
    }
    /**
     * 🎤 Listen for audio chunk data
     * @param handler - Function to handle audio chunks
     * @returns Cleanup function to remove the handler
     */
    onAudioChunk(handler) {
        return this.addHandler(types_1.StreamType.AUDIO_CHUNK, handler);
    }
    // System event handlers
    onConnected(handler) {
        this.emitter.on('connected', handler);
        return () => this.emitter.off('connected', handler);
    }
    onDisconnected(handler) {
        this.emitter.on('disconnected', handler);
        return () => this.emitter.off('disconnected', handler);
    }
    onError(handler) {
        this.emitter.on('error', handler);
        return () => this.emitter.off('error', handler);
    }
    onSettingsUpdate(handler) {
        this.emitter.on('settings_update', handler);
        return () => this.emitter.off('settings_update', handler);
    }
    /**
     * 🌐 Listen for dashboard mode changes
     * @param handler - Function to handle dashboard mode changes
     * @returns Cleanup function to remove the handler
     */
    onDashboardModeChange(handler) {
        this.emitter.on('dashboard_mode_change', handler);
        return () => this.emitter.off('dashboard_mode_change', handler);
    }
    /**
     * 🌐 Listen for dashboard always-on mode changes
     * @param handler - Function to handle dashboard always-on mode changes
     * @returns Cleanup function to remove the handler
     */
    onDashboardAlwaysOnChange(handler) {
        this.emitter.on('dashboard_always_on_change', handler);
        return () => this.emitter.off('dashboard_always_on_change', handler);
    }
    /**
     * 🔄 Listen for changes to a specific setting
     * @param key - Setting key to monitor
     * @param handler - Function to handle setting value changes
     * @returns Cleanup function to remove the handler
     */
    onSettingChange(key, handler) {
        let previousValue = undefined;
        const settingsHandler = (settings) => {
            try {
                const setting = settings.find(s => s.key === key);
                if (setting) {
                    // Only call handler if value has changed
                    if (setting.value !== previousValue) {
                        const newValue = setting.value;
                        handler(newValue, previousValue);
                        previousValue = newValue;
                    }
                }
            }
            catch (error) {
                console.error(`Error in onSettingChange handler for key "${key}":`, error);
            }
        };
        this.emitter.on('settings_update', settingsHandler);
        this.emitter.on('connected', settingsHandler); // Also check when first connected
        return () => {
            this.emitter.off('settings_update', settingsHandler);
            this.emitter.off('connected', settingsHandler);
        };
    }
    /**
     * 🔄 Generic event handler
     *
     * Use this for stream types without specific handler methods
     */
    on(type, handler) {
        return this.addHandler(type, handler);
    }
    /**
     * ➕ Add an event handler and subscribe if needed
     */
    addHandler(type, handler) {
        const handlers = this.handlers.get(type) ?? new Set();
        if (handlers.size === 0) {
            // console.log(`$$$#### Subscribing to ${type}`);
            this.handlers.set(type, handlers);
            this.subscribe(type);
        }
        // console.log(`((())) Handler: ${handler.toString()}`);
        // console.log(`$$$#### Handlers: ${JSON.stringify(handlers)}`);
        handlers.add(handler);
        // console.log(`@@@@ #### Handlers: ${JSON.stringify(handlers)}`);
        // console.log(`#### Added handler for ${type}`);
        // console.log('Handler details:', {
        //   type,
        //   handler: handler.toString(),
        //   handlerCount: handlers.size,
        //   allHandlers: Array.from(handlers).map(h => h.toString())
        // });
        return () => this.removeHandler(type, handler);
    }
    /**
     * ➖ Remove an event handler
     */
    removeHandler(type, handler) {
        const handlers = this.handlers.get(type);
        if (!handlers)
            return;
        handlers.delete(handler);
        if (handlers.size === 0) {
            this.handlers.delete(type);
            this.unsubscribe(type);
        }
    }
    /**
     * 📡 Emit an event to all registered handlers with error isolation
     */
    emit(event, data) {
        try {
            // Emit to EventEmitter handlers (system events)
            // console.log(`#### Emitting to ${event}`);
            this.emitter.emit(event, data);
            // Emit to stream handlers if applicable
            const handlers = this.handlers.get(event);
            // console.log(`#### Handlers: ${JSON.stringify(handlers)}`);
            if (handlers) {
                // Create array of handlers to prevent modification during iteration
                const handlersArray = Array.from(handlers);
                // console.log(`((())) HandlersArray: ${JSON.stringify(handlersArray)}`);
                // Execute each handler in isolated try/catch to prevent one handler
                // from crashing the entire TPA
                handlersArray.forEach(handler => {
                    try {
                        handler(data);
                    }
                    catch (handlerError) {
                        // Log the error but don't let it propagate
                        console.error(`Error in handler for event '${String(event)}':`, handlerError);
                        // Emit an error event for tracking purposes
                        if (event !== 'error') { // Prevent infinite recursion
                            const errorMessage = handlerError instanceof Error
                                ? handlerError.message
                                : String(handlerError);
                            this.emitter.emit('error', new Error(`Handler error for event '${String(event)}': ${errorMessage}`));
                        }
                    }
                });
            }
        }
        catch (emitError) {
            // Catch any errors in the emission process itself
            console.error(`Fatal error emitting event '${String(event)}':`, emitError);
            // Try to emit an error event if we're not already handling an error
            if (event !== 'error') {
                try {
                    const errorMessage = emitError instanceof Error
                        ? emitError.message
                        : String(emitError);
                    this.emitter.emit('error', new Error(`Event emission error for '${String(event)}': ${errorMessage}`));
                }
                catch (nestedError) {
                    // If even this fails, just log it - nothing more we can do
                    console.error('Failed to emit error event:', nestedError);
                }
            }
        }
    }
    /**
     * 📨 Listen for custom messages with a specific action
     * @param action - The action identifier to filter by
     * @param handler - Function to handle the message
     * @returns Cleanup function to remove the handler
     */
    onCustomMessage(action, handler) {
        const messageHandler = (message) => {
            if (message.action === action) {
                handler(message.payload);
            }
        };
        this.emitter.on('custom_message', messageHandler);
        return () => this.emitter.off('custom_message', messageHandler);
    }
}
exports.EventManager = EventManager;
