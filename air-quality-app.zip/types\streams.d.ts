/**
 * Types of streams that TPAs can subscribe to
 *
 * These are events and data that TPAs can receive from the cloud.
 * Not all message types can be subscribed to as streams.
 */
export declare enum StreamType {
    BUTTON_PRESS = "button_press",
    HEAD_POSITION = "head_position",
    GLASSES_BATTERY_UPDATE = "glasses_battery_update",
    PHONE_BATTERY_UPDATE = "phone_battery_update",
    GLASSES_CONNECTION_STATE = "glasses_connection_state",
    LOCATION_UPDATE = "location_update",
    TRANSCRIPTION = "transcription",
    TRANSLATION = "translation",
    VAD = "VAD",
    AUDIO_CHUNK = "audio_chunk",
    PHONE_NOTIFICATION = "phone_notification",
    NOTIFICATION_DISMISSED = "notification_dismissed",
    CALENDAR_EVENT = "calendar_event",
    START_APP = "start_app",
    STOP_APP = "stop_app",
    OPEN_DASHBOARD = "open_dashboard",
    CORE_STATUS_UPDATE = "core_status_update",
    VIDEO = "video",
    PHOTO_REQUEST = "photo_request",
    VIDEO_STREAM_REQUEST = "video_stream_request",
    ALL = "all",
    WILDCARD = "*",
    AUGMENTOS_SETTINGS_UPDATE_REQUEST = "settings_update_request",
    CUSTOM_MESSAGE = "custom_message"
}
/**
 * Extended StreamType to support language-specific streams
 * This allows us to treat language-specific strings as StreamType values
 */
export type ExtendedStreamType = StreamType | string;
/**
 * Categories of stream data
 */
export declare enum StreamCategory {
    /** Data from hardware sensors */
    HARDWARE = "hardware",
    /** Audio processing results */
    AUDIO = "audio",
    /** Phone-related events */
    PHONE = "phone",
    /** System-level events */
    SYSTEM = "system"
}
/**
 * Map of stream categories for each stream type
 */
export declare const STREAM_CATEGORIES: Record<StreamType, StreamCategory>;
/**
 * Branded type for TypeScript to recognize language-specific stream types
 * This helps maintain type safety when using language-specific streams
 */
export type LanguageStreamType<T extends string> = T & {
    __languageStreamBrand: never;
};
/**
 * Structure of a parsed language stream subscription
 */
export interface LanguageStreamInfo {
    type: StreamType;
    baseType: string;
    transcribeLanguage: string;
    translateLanguage?: string;
    original: ExtendedStreamType;
}
/**
 * Check if a string is a valid language code
 * Simple validation for language code format: xx-XX (e.g., en-US)
 */
export declare function isValidLanguageCode(code: string): boolean;
/**
 * Parse a subscription string to extract language information
 *
 * @param subscription Subscription string (e.g., "transcription:en-US" or "translation:es-ES-to-en-US")
 * @returns Parsed language stream info or null if not a language-specific subscription
 */
export declare function parseLanguageStream(subscription: ExtendedStreamType): LanguageStreamInfo | null;
/**
 * Create a transcription stream identifier for a specific language
 * Returns a type-safe stream type that can be used like a StreamType
 *
 * @param language Language code (e.g., "en-US")
 * @returns Typed stream identifier
 */
export declare function createTranscriptionStream(language: string): ExtendedStreamType;
/**
 * Create a translation stream identifier for a language pair
 * Returns a type-safe stream type that can be used like a StreamType
 *
 * @param sourceLanguage Source language code (e.g., "es-ES")
 * @param targetLanguage Target language code (e.g., "en-US")
 * @returns Typed stream identifier
 */
export declare function createTranslationStream(sourceLanguage: string, targetLanguage: string): ExtendedStreamType;
/**
 * Check if a subscription is a valid stream type
 * This handles both enum-based StreamType values and language-specific stream formats
 *
 * @param subscription Subscription to validate
 * @returns True if valid, false otherwise
 */
export declare function isValidStreamType(subscription: ExtendedStreamType): boolean;
/**
 * Helper function to check if a stream type is of a particular category
 * Works with both standard and language-specific stream types
 */
export declare function isStreamCategory(streamType: ExtendedStreamType, category: StreamCategory): boolean;
/**
 * Helper function to get all stream types in a category
 */
export declare function getStreamTypesByCategory(category: StreamCategory): StreamType[];
/**
 * Get the base StreamType for a subscription
 * Works with both standard StreamType values and language-specific formats
 *
 * @param subscription Subscription string or StreamType
 * @returns The base StreamType enum value
 */
export declare function getBaseStreamType(subscription: ExtendedStreamType): StreamType | null;
/**
 * Check if a stream is a language-specific stream
 */
export declare function isLanguageStream(subscription: ExtendedStreamType): boolean;
/**
 * Get language information from a stream type
 * Returns null for regular stream types
 */
export declare function getLanguageInfo(subscription: ExtendedStreamType): LanguageStreamInfo | null;
//# sourceMappingURL=streams.d.ts.map