"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardMode = void 0;
/**
 * Dashboard modes supported by the system
 */
var DashboardMode;
(function (DashboardMode) {
    DashboardMode["MAIN"] = "main";
    DashboardMode["EXPANDED"] = "expanded";
    // ALWAYS_ON = 'always_on'  // Persistent minimal dashboard
})(DashboardMode || (exports.DashboardMode = DashboardMode = {}));
