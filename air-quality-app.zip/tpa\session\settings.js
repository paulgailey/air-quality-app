"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsManager = void 0;
/**
 * 🔧 Settings Manager Module
 *
 * Manages TPA settings with automatic synchronization and change notifications.
 * Provides type-safe access to settings with default values.
 */
const events_1 = __importDefault(require("events"));
const api_client_1 = require("./api-client");
// import { logger } from '@augmentos/utils'; // Ensure logger is available
// Note(Isaiah): Let's not import @augmentos/utils in the SDK to avoid circular dependencies. Also i'm deprecating it in favor of the new logging system.
const logger_1 = require("../../logging/logger"); // Adjust import path as needed
/**
 * Internal event names
 */
var SettingsEvents;
(function (SettingsEvents) {
    SettingsEvents["CHANGE"] = "settings:change";
    SettingsEvents["VALUE_CHANGE"] = "settings:value:";
})(SettingsEvents || (SettingsEvents = {}));
/**
 * 🔧 Settings Manager
 *
 * Provides a type-safe interface for accessing and reacting to TPA settings.
 * Automatically synchronizes with AugmentOS Cloud.
 */
class SettingsManager {
    /**
     * Create a new settings manager
     *
     * @param initialSettings Initial settings values (if available)
     * @param packageName Package name for the TPA
     * @param wsUrl WebSocket URL (for deriving HTTP API URL)
     * @param userId User ID (for authenticated requests)
     * @param subscribeFn Optional function to call to subscribe to streams
     */
    constructor(initialSettings = [], packageName, wsUrl, userId, subscribeFn // Added parameter
    ) {
        // Current settings values
        this.settings = [];
        // Event emitter for change notifications
        this.emitter = new events_1.default();
        // --- AugmentOS settings event system ---
        this.augmentosSettings = {};
        this.augmentosEmitter = new events_1.default();
        this.settings = [...initialSettings];
        this.subscribeFn = subscribeFn; // Store the subscribe function
        // Create API client if we have enough information
        if (packageName) {
            this.apiClient = new api_client_1.ApiClient(packageName, wsUrl, userId);
        }
    }
    /**
     * Configure the API client
     *
     * @param packageName Package name for the TPA
     * @param wsUrl WebSocket URL
     * @param userId User ID
     */
    configureApiClient(packageName, wsUrl, userId) {
        if (!this.apiClient) {
            this.apiClient = new api_client_1.ApiClient(packageName, wsUrl, userId);
        }
        else {
            this.apiClient.setWebSocketUrl(wsUrl);
            this.apiClient.setUserId(userId);
        }
    }
    /**
     * Update the current settings
     * This is called internally when settings are loaded or changed
     *
     * @param newSettings New settings values
     * @returns Map of changed settings
     */
    updateSettings(newSettings) {
        const changes = {};
        // Copy the new settings
        const updatedSettings = [...newSettings];
        // Detect changes comparing old and new settings
        for (const newSetting of updatedSettings) {
            const oldSetting = this.settings.find(s => s.key === newSetting.key);
            // Skip if value hasn't changed
            if (oldSetting && this.areEqual(oldSetting.value, newSetting.value)) {
                continue;
            }
            // Record change
            changes[newSetting.key] = {
                oldValue: oldSetting?.value,
                newValue: newSetting.value
            };
        }
        // Check for removed settings
        for (const oldSetting of this.settings) {
            const stillExists = updatedSettings.some(s => s.key === oldSetting.key);
            if (!stillExists) {
                changes[oldSetting.key] = {
                    oldValue: oldSetting.value,
                    newValue: undefined
                };
            }
        }
        // If there are changes, update the settings and emit events
        if (Object.keys(changes).length > 0) {
            this.settings = updatedSettings;
            this.emitChanges(changes);
        }
        return changes;
    }
    /**
     * Check if two setting values are equal
     *
     * @param a First value
     * @param b Second value
     * @returns True if the values are equal
     */
    areEqual(a, b) {
        // Simple equality check - for objects, this won't do a deep equality check
        // but for most setting values (strings, numbers, booleans) it works
        return a === b;
    }
    /**
     * Emit change events for updated settings
     *
     * @param changes Map of changed settings
     */
    emitChanges(changes) {
        // Emit the general change event
        this.emitter.emit(SettingsEvents.CHANGE, changes);
        // Emit individual value change events
        for (const [key, change] of Object.entries(changes)) {
            this.emitter.emit(`${SettingsEvents.VALUE_CHANGE}${key}`, change.newValue, change.oldValue);
        }
    }
    /**
     * 🔄 Listen for changes to any setting
     *
     * @param handler Function to call when settings change
     * @returns Function to remove the listener
     *
     * @example
     * ```typescript
     * settings.onChange((changes) => {
     *   console.log('Settings changed:', changes);
     * });
     * ```
     */
    onChange(handler) {
        this.emitter.on(SettingsEvents.CHANGE, handler);
        return () => this.emitter.off(SettingsEvents.CHANGE, handler);
    }
    /**
     * 🔄 Listen for changes to a specific setting
     *
     * @param key Setting key to monitor
     * @param handler Function to call when the setting changes
     * @returns Function to remove the listener
     *
     * @example
     * ```typescript
     * settings.onValueChange('transcribe_language', (newValue, oldValue) => {
     *   console.log(`Language changed from ${oldValue} to ${newValue}`);
     * });
     * ```
     */
    onValueChange(key, handler) {
        const eventName = `${SettingsEvents.VALUE_CHANGE}${key}`;
        this.emitter.on(eventName, handler);
        return () => this.emitter.off(eventName, handler);
    }
    /**
     * 🔍 Check if a setting exists
     *
     * @param key Setting key to check
     * @returns True if the setting exists
     */
    has(key) {
        return this.settings.some(s => s.key === key);
    }
    /**
     * 🔍 Get all settings
     *
     * @returns Copy of all settings
     */
    getAll() {
        return [...this.settings];
    }
    /**
     * 🔍 Get a setting value with type safety
     *
     * @param key Setting key to get
     * @param defaultValue Default value if setting doesn't exist or is undefined
     * @returns Setting value or default value
     *
     * @example
     * ```typescript
     * const lineWidth = settings.get<number>('line_width', 30);
     * const language = settings.get<string>('transcribe_language', 'English');
     * ```
     */
    get(key, defaultValue) {
        const setting = this.settings.find(s => s.key === key);
        if (setting && setting.value !== undefined) {
            return setting.value;
        }
        return defaultValue;
    }
    /**
     * 🔍 Find a setting by key
     *
     * @param key Setting key to find
     * @returns Setting object or undefined
     */
    getSetting(key) {
        return this.settings.find(s => s.key === key);
    }
    /**
     * 🔄 Fetch settings from the cloud
     * This is generally not needed since settings are automatically kept in sync,
     * but can be used to force a refresh if needed.
     *
     * @returns Promise that resolves to the updated settings
     * @throws Error if the API client is not configured or the request fails
     */
    async fetch() {
        if (!this.apiClient) {
            throw new Error('Settings API client is not configured');
        }
        try {
            const newSettings = await this.apiClient.fetchSettings();
            this.updateSettings(newSettings);
            return this.settings;
        }
        catch (error) {
            console.error('Error fetching settings:', error);
            throw error;
        }
    }
    /**
     * Listen for changes to a specific AugmentOS setting (e.g., metricSystemEnabled)
     * This is a convenience wrapper for onValueChange for well-known augmentosSettings keys.
     * @param key The augmentosSettings key to listen for (e.g., 'metricSystemEnabled')
     * @param handler Function to call when the value changes
     * @returns Function to remove the listener
     */
    onAugmentosSettingsChange(key, handler) {
        return this.onValueChange(key, handler);
    }
    /**
     * Update the current AugmentOS settings
     * Compares new and old values, emits per-key events, and updates stored values.
     * @param newSettings The new AugmentOS settings object
     */
    updateAugmentosSettings(newSettings) {
        const oldSettings = this.augmentosSettings;
        logger_1.logger.debug(`[SettingsManager] Updating AugmentOS settings. New settings:`, newSettings);
        for (const key of Object.keys(newSettings)) {
            const oldValue = oldSettings[key];
            const newValue = newSettings[key];
            if (oldValue !== newValue) {
                logger_1.logger.info(`[SettingsManager] AugmentOS setting '${key}' changed: ${oldValue} -> ${newValue}. Emitting event.`);
                this.augmentosEmitter.emit(`augmentos:value:${key}`, newValue, oldValue);
            }
        }
        // Also handle keys that might have been removed from newSettings but existed in oldSettings
        for (const key of Object.keys(oldSettings)) {
            if (!(key in newSettings)) {
                logger_1.logger.info(`[SettingsManager] AugmentOS setting '${key}' removed. Old value: ${oldSettings[key]}. Emitting event with undefined newValue.`);
                this.augmentosEmitter.emit(`augmentos:value:${key}`, undefined, oldSettings[key]);
            }
        }
        this.augmentosSettings = { ...newSettings };
        logger_1.logger.debug(`[SettingsManager] Finished updating AugmentOS settings. Current state:`, this.augmentosSettings);
    }
    /**
     * Subscribe to changes for a specific AugmentOS setting (e.g., 'metricSystemEnabled')
     * @param key The AugmentOS setting key to listen for
     * @param handler Function to call when the value changes (newValue, oldValue)
     * @returns Function to remove the listener
     */
    onAugmentosSettingChange(key, handler) {
        const eventName = `augmentos:value:${key}`;
        logger_1.logger.info(`[SettingsManager] Registering handler for AugmentOS setting '${key}' on event '${eventName}'.`);
        this.augmentosEmitter.on(eventName, (...args) => {
            logger_1.logger.info(`[SettingsManager] AugmentOS setting '${key}' event fired. Args:`, args);
            handler(...args);
        });
        if (this.subscribeFn) {
            const subscriptionKey = `augmentos:${key}`;
            logger_1.logger.info(`[SettingsManager] Calling subscribeFn for stream '${subscriptionKey}'.`);
            this.subscribeFn([subscriptionKey])
                .then(() => {
                logger_1.logger.info(`[SettingsManager] subscribeFn resolved for stream '${subscriptionKey}'.`);
            })
                .catch(err => {
                logger_1.logger.error(`[SettingsManager] subscribeFn failed for stream '${subscriptionKey}':`, err);
            });
        }
        else {
            logger_1.logger.warn(`[SettingsManager] 'subscribeFn' not provided. Cannot auto-subscribe for AugmentOS setting '${key}'. Manual TPA subscription might be required.`);
        }
        return () => {
            logger_1.logger.info(`[SettingsManager] Unregistering handler for AugmentOS setting '${key}' from event '${eventName}'.`);
            this.augmentosEmitter.off(eventName, handler);
        };
    }
    /**
     * Get the current value of an AugmentOS setting
     */
    getAugmentosSetting(key, defaultValue) {
        console.log(`[SettingsManager] Getting AugmentOS setting '${key}' with settings:`, this.augmentosSettings);
        if (key in this.augmentosSettings) {
            return this.augmentosSettings[key];
        }
        return defaultValue;
    }
}
exports.SettingsManager = SettingsManager;
