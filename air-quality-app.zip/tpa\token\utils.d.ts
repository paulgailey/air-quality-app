import { TpaTokenPayload, TokenValidationResult, TokenConfig } from '../../types/token';
/**
 * Create a TPA token for a user session
 *
 * @param payload - Token payload data
 * @param config - Token configuration
 * @returns JWT token string
 *
 * @example
 * ```typescript
 * const token = createToken(
 *   {
 *     userId: 'user123',
 *     packageName: 'org.example.myapp',
 *     sessionId: 'session789'
 *   },
 *   { secretKey: 'your_secret_key' }
 * );
 * ```
 */
export declare function createToken(payload: Omit<TpaTokenPayload, 'iat' | 'exp'>, config: TokenConfig): string;
/**
 * Validate and decode a TPA token
 *
 * @param token - JWT token string
 * @param secretKey - Secret key used for validation
 * @returns Token validation result
 *
 * @example
 * ```typescript
 * const result = validateToken('eyJhbGciOiJIUzI1...', 'your_secret_key');
 * if (result.valid) {
 *   // Use result.payload
 * }
 * ```
 */
export declare function validateToken(token: string, secretKey: string): TokenValidationResult;
/**
 * Generate a webview URL with an embedded TPA token
 *
 * @param baseUrl - Base URL of the webview
 * @param token - JWT token string
 * @returns Full URL with token parameter
 *
 * @example
 * ```typescript
 * const url = generateWebviewUrl(
 *   'https://example.com/webview',
 *   'eyJhbGciOiJIUzI1...'
 * );
 * // Returns: https://example.com/webview?token=eyJhbGciOiJIUzI1...
 * ```
 */
export declare function generateWebviewUrl(baseUrl: string, token: string): string;
/**
 * Extract a TPA token from a URL
 *
 * @param url - URL string containing a token parameter
 * @returns Token string or null if not found
 *
 * @example
 * ```typescript
 * const token = extractTokenFromUrl(
 *   'https://example.com/webview?token=eyJhbGciOiJIUzI1...'
 * );
 * ```
 */
export declare function extractTokenFromUrl(url: string): string | null;
//# sourceMappingURL=utils.d.ts.map