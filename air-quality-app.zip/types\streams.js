"use strict";
// src/streams.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.STREAM_CATEGORIES = exports.StreamCategory = exports.StreamType = void 0;
exports.isValidLanguageCode = isValidLanguageCode;
exports.parseLanguageStream = parseLanguageStream;
exports.createTranscriptionStream = createTranscriptionStream;
exports.createTranslationStream = createTranslationStream;
exports.isValidStreamType = isValidStreamType;
exports.isStreamCategory = isStreamCategory;
exports.getStreamTypesByCategory = getStreamTypesByCategory;
exports.getBaseStreamType = getBaseStreamType;
exports.isLanguageStream = isLanguageStream;
exports.getLanguageInfo = getLanguageInfo;
/**
 * Types of streams that TPAs can subscribe to
 *
 * These are events and data that TPAs can receive from the cloud.
 * Not all message types can be subscribed to as streams.
 */
var StreamType;
(function (StreamType) {
    // Hardware streams
    StreamType["BUTTON_PRESS"] = "button_press";
    StreamType["HEAD_POSITION"] = "head_position";
    StreamType["GLASSES_BATTERY_UPDATE"] = "glasses_battery_update";
    StreamType["PHONE_BATTERY_UPDATE"] = "phone_battery_update";
    StreamType["GLASSES_CONNECTION_STATE"] = "glasses_connection_state";
    StreamType["LOCATION_UPDATE"] = "location_update";
    // Audio streams
    StreamType["TRANSCRIPTION"] = "transcription";
    StreamType["TRANSLATION"] = "translation";
    StreamType["VAD"] = "VAD";
    StreamType["AUDIO_CHUNK"] = "audio_chunk";
    // Phone streams
    StreamType["PHONE_NOTIFICATION"] = "phone_notification";
    StreamType["NOTIFICATION_DISMISSED"] = "notification_dismissed";
    StreamType["CALENDAR_EVENT"] = "calendar_event";
    // System streams
    StreamType["START_APP"] = "start_app";
    StreamType["STOP_APP"] = "stop_app";
    StreamType["OPEN_DASHBOARD"] = "open_dashboard";
    StreamType["CORE_STATUS_UPDATE"] = "core_status_update";
    // Video streams
    StreamType["VIDEO"] = "video";
    StreamType["PHOTO_REQUEST"] = "photo_request";
    StreamType["VIDEO_STREAM_REQUEST"] = "video_stream_request";
    // Special subscription types
    StreamType["ALL"] = "all";
    StreamType["WILDCARD"] = "*";
    // New stream type
    StreamType["AUGMENTOS_SETTINGS_UPDATE_REQUEST"] = "settings_update_request";
    StreamType["CUSTOM_MESSAGE"] = "custom_message";
})(StreamType || (exports.StreamType = StreamType = {}));
/**
 * Categories of stream data
 */
var StreamCategory;
(function (StreamCategory) {
    /** Data from hardware sensors */
    StreamCategory["HARDWARE"] = "hardware";
    /** Audio processing results */
    StreamCategory["AUDIO"] = "audio";
    /** Phone-related events */
    StreamCategory["PHONE"] = "phone";
    /** System-level events */
    StreamCategory["SYSTEM"] = "system";
})(StreamCategory || (exports.StreamCategory = StreamCategory = {}));
/**
 * Map of stream categories for each stream type
 */
exports.STREAM_CATEGORIES = {
    [StreamType.BUTTON_PRESS]: StreamCategory.HARDWARE,
    [StreamType.HEAD_POSITION]: StreamCategory.HARDWARE,
    [StreamType.GLASSES_BATTERY_UPDATE]: StreamCategory.HARDWARE,
    [StreamType.PHONE_BATTERY_UPDATE]: StreamCategory.HARDWARE,
    [StreamType.GLASSES_CONNECTION_STATE]: StreamCategory.HARDWARE,
    [StreamType.LOCATION_UPDATE]: StreamCategory.HARDWARE,
    [StreamType.TRANSCRIPTION]: StreamCategory.AUDIO,
    [StreamType.TRANSLATION]: StreamCategory.AUDIO,
    [StreamType.VAD]: StreamCategory.AUDIO,
    [StreamType.AUDIO_CHUNK]: StreamCategory.AUDIO,
    [StreamType.PHONE_NOTIFICATION]: StreamCategory.PHONE,
    [StreamType.NOTIFICATION_DISMISSED]: StreamCategory.PHONE,
    [StreamType.CALENDAR_EVENT]: StreamCategory.PHONE,
    [StreamType.START_APP]: StreamCategory.SYSTEM,
    [StreamType.STOP_APP]: StreamCategory.SYSTEM,
    [StreamType.OPEN_DASHBOARD]: StreamCategory.SYSTEM,
    [StreamType.CORE_STATUS_UPDATE]: StreamCategory.SYSTEM,
    [StreamType.VIDEO]: StreamCategory.HARDWARE,
    [StreamType.PHOTO_REQUEST]: StreamCategory.HARDWARE,
    [StreamType.VIDEO_STREAM_REQUEST]: StreamCategory.HARDWARE,
    [StreamType.ALL]: StreamCategory.SYSTEM,
    [StreamType.WILDCARD]: StreamCategory.SYSTEM,
    [StreamType.AUGMENTOS_SETTINGS_UPDATE_REQUEST]: StreamCategory.SYSTEM,
    [StreamType.CUSTOM_MESSAGE]: StreamCategory.SYSTEM
};
/**
 * Create a language-branded stream type
 * This is a type helper to ensure type safety for language-specific streams
 */
function createLanguageStream(type) {
    return type;
}
/**
 * Check if a string is a valid language code
 * Simple validation for language code format: xx-XX (e.g., en-US)
 */
function isValidLanguageCode(code) {
    return /^[a-z]{2}-[A-Z]{2}$/.test(code);
}
/**
 * Parse a subscription string to extract language information
 *
 * @param subscription Subscription string (e.g., "transcription:en-US" or "translation:es-ES-to-en-US")
 * @returns Parsed language stream info or null if not a language-specific subscription
 */
function parseLanguageStream(subscription) {
    if (typeof subscription !== 'string') {
        return null;
    }
    // console.log(`🎤 Parsing language stream: ${subscription}`);
    // Handle transcription format (transcription:en-US)
    if (subscription.startsWith(`${StreamType.TRANSCRIPTION}:`)) {
        const [baseType, languageCode] = subscription.split(':');
        // console.log(`🎤 Parsing transcription stream: ${subscription}`);
        // console.log(`🎤 Language code: ${languageCode}`);
        if (languageCode && isValidLanguageCode(languageCode)) {
            return {
                type: StreamType.TRANSCRIPTION,
                baseType,
                transcribeLanguage: languageCode,
                original: subscription
            };
        }
    }
    // Handle translation format (translation:es-ES-to-en-US)
    if (subscription.startsWith(`${StreamType.TRANSLATION}:`)) {
        const [baseType, languagePair] = subscription.split(':');
        const [sourceLanguage, targetLanguage] = languagePair?.split('-to-') ?? [];
        // console.log(`🎤 Parsing translation stream: ${subscription}`);
        // console.log(`🎤 Source language: ${sourceLanguage}`);
        // console.log(`🎤 Target language: ${targetLanguage}`);
        if (sourceLanguage && targetLanguage &&
            isValidLanguageCode(sourceLanguage) &&
            isValidLanguageCode(targetLanguage)) {
            return {
                type: StreamType.TRANSLATION,
                baseType,
                transcribeLanguage: sourceLanguage,
                translateLanguage: targetLanguage,
                original: subscription
            };
        }
    }
    return null;
}
/**
 * Create a transcription stream identifier for a specific language
 * Returns a type-safe stream type that can be used like a StreamType
 *
 * @param language Language code (e.g., "en-US")
 * @returns Typed stream identifier
 */
function createTranscriptionStream(language) {
    if (!isValidLanguageCode(language)) {
        throw new Error(`Invalid language code: ${language}`);
    }
    return createLanguageStream(`${StreamType.TRANSCRIPTION}:${language}`);
}
/**
 * Create a translation stream identifier for a language pair
 * Returns a type-safe stream type that can be used like a StreamType
 *
 * @param sourceLanguage Source language code (e.g., "es-ES")
 * @param targetLanguage Target language code (e.g., "en-US")
 * @returns Typed stream identifier
 */
function createTranslationStream(sourceLanguage, targetLanguage) {
    if (!isValidLanguageCode(sourceLanguage) || !isValidLanguageCode(targetLanguage)) {
        throw new Error(`Invalid language code(s): ${sourceLanguage}, ${targetLanguage}`);
    }
    return createLanguageStream(`${StreamType.TRANSLATION}:${sourceLanguage}-to-${targetLanguage}`);
}
/**
 * Check if a subscription is a valid stream type
 * This handles both enum-based StreamType values and language-specific stream formats
 *
 * @param subscription Subscription to validate
 * @returns True if valid, false otherwise
 */
function isValidStreamType(subscription) {
    // Check if it's a standard StreamType
    if (Object.values(StreamType).includes(subscription)) {
        return true;
    }
    // Check if it's a valid language-specific stream
    const languageStream = parseLanguageStream(subscription);
    return languageStream !== null;
}
/**
 * Helper function to check if a stream type is of a particular category
 * Works with both standard and language-specific stream types
 */
function isStreamCategory(streamType, category) {
    const baseType = getBaseStreamType(streamType);
    return baseType ? exports.STREAM_CATEGORIES[baseType] === category : false;
}
/**
 * Helper function to get all stream types in a category
 */
function getStreamTypesByCategory(category) {
    return Object.entries(exports.STREAM_CATEGORIES)
        .filter(([_, cat]) => cat === category)
        .map(([type]) => type);
}
/**
 * Get the base StreamType for a subscription
 * Works with both standard StreamType values and language-specific formats
 *
 * @param subscription Subscription string or StreamType
 * @returns The base StreamType enum value
 */
function getBaseStreamType(subscription) {
    // Check if it's already a standard StreamType
    if (Object.values(StreamType).includes(subscription)) {
        return subscription;
    }
    // Check if it's a language-specific stream
    const languageStream = parseLanguageStream(subscription);
    return languageStream?.type ?? null;
}
/**
 * Check if a stream is a language-specific stream
 */
function isLanguageStream(subscription) {
    return parseLanguageStream(subscription) !== null;
}
/**
 * Get language information from a stream type
 * Returns null for regular stream types
 */
function getLanguageInfo(subscription) {
    return parseLanguageStream(subscription);
}
