/**
 * Resource Tracker
 *
 * A utility class for tracking and automatically cleaning up resources
 * like timers, event listeners, and other disposable objects.
 *
 * This helps prevent memory leaks by ensuring that all resources are
 * properly disposed when they're no longer needed.
 */
/**
 * Type for a cleanup function that doesn't take any arguments
 */
export type CleanupFunction = () => void;
/**
 * Type for any object with a dispose or close method
 */
export interface Disposable {
    dispose?: () => void;
    close?: () => void;
}
/**
 * Manages resources to prevent memory leaks
 */
export declare class ResourceTracker {
    private cleanupFunctions;
    private isDisposed;
    /**
     * Add a cleanup function to be executed when dispose() is called
     *
     * @param cleanup - The cleanup function to register
     * @returns A function that will remove this cleanup function
     */
    track(cleanup: CleanupFunction): CleanupFunction;
    /**
     * Track a disposable object (anything with a dispose or close method)
     *
     * @param disposable - The object to track
     * @returns A function that will remove this disposable
     */
    trackDisposable(disposable: Disposable): CleanupFunction;
    /**
     * Track a timer and ensure it gets cleared
     *
     * @param timerId - The timer ID to track
     * @param isInterval - Whether this is an interval (true) or timeout (false)
     * @returns A function that will remove this timer
     */
    trackTimer(timerId: NodeJS.Timeout, isInterval?: boolean): CleanupFunction;
    /**
     * Track a timeout and ensure it gets cleared
     *
     * @param timerId - The timeout ID to track
     * @returns A function that will remove this timeout
     */
    trackTimeout(timerId: NodeJS.Timeout): CleanupFunction;
    /**
     * Track an interval and ensure it gets cleared
     *
     * @param timerId - The interval ID to track
     * @returns A function that will remove this interval
     */
    trackInterval(timerId: NodeJS.Timeout): CleanupFunction;
    /**
     * Create a tracked timeout
     *
     * @param callback - Function to call when the timeout expires
     * @param ms - Milliseconds to wait
     * @returns The timeout ID
     */
    setTimeout(callback: (...args: any[]) => void, ms: number): NodeJS.Timeout;
    /**
     * Create a tracked interval
     *
     * @param callback - Function to call at each interval
     * @param ms - Milliseconds between intervals
     * @returns The interval ID
     */
    setInterval(callback: (...args: any[]) => void, ms: number): NodeJS.Timeout;
    /**
     * Dispose of all tracked resources
     */
    dispose(): void;
    /**
     * Check if this tracker has been disposed
     */
    get disposed(): boolean;
}
/**
 * Create a new ResourceTracker instance
 *
 * @returns A new ResourceTracker
 */
export declare function createResourceTracker(): ResourceTracker;
//# sourceMappingURL=resource-tracker.d.ts.map