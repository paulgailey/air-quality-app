"use strict";
// src/messages/tpa-to-cloud.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTpaConnectionInit = isTpaConnectionInit;
exports.isTpaSubscriptionUpdate = isTpaSubscriptionUpdate;
exports.isDisplayRequest = isDisplayRequest;
exports.isPhotoRequest = isPhotoRequest;
exports.isVideoStreamRequest = isVideoStreamRequest;
exports.isDashboardContentUpdate = isDashboardContentUpdate;
exports.isDashboardModeChange = isDashboardModeChange;
exports.isDashboardSystemUpdate = isDashboardSystemUpdate;
const message_types_1 = require("../message-types");
/**
 * Type guard to check if a message is a TPA connection init
 */
function isTpaConnectionInit(message) {
    return message.type === message_types_1.TpaToCloudMessageType.CONNECTION_INIT;
}
/**
 * Type guard to check if a message is a TPA subscription update
 */
function isTpaSubscriptionUpdate(message) {
    return message.type === message_types_1.TpaToCloudMessageType.SUBSCRIPTION_UPDATE;
}
/**
 * Type guard to check if a message is a TPA display request
 */
function isDisplayRequest(message) {
    return message.type === message_types_1.TpaToCloudMessageType.DISPLAY_REQUEST;
}
/**
 * Type guard to check if a message is a TPA photo request
 */
function isPhotoRequest(message) {
    return message.type === message_types_1.TpaToCloudMessageType.PHOTO_REQUEST;
}
/**
 * Type guard to check if a message is a TPA video stream request
 */
function isVideoStreamRequest(message) {
    return message.type === message_types_1.TpaToCloudMessageType.VIDEO_STREAM_REQUEST;
}
/**
 * Type guard to check if a message is a dashboard content update
 */
function isDashboardContentUpdate(message) {
    return message.type === message_types_1.TpaToCloudMessageType.DASHBOARD_CONTENT_UPDATE;
}
/**
 * Type guard to check if a message is a dashboard mode change
 */
function isDashboardModeChange(message) {
    return message.type === message_types_1.TpaToCloudMessageType.DASHBOARD_MODE_CHANGE;
}
/**
 * Type guard to check if a message is a dashboard system update
 */
function isDashboardSystemUpdate(message) {
    return message.type === message_types_1.TpaToCloudMessageType.DASHBOARD_SYSTEM_UPDATE;
}
