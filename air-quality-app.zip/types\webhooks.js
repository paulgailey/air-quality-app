"use strict";
// src/webhook.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookRequestType = void 0;
exports.isSessionWebhookRequest = isSessionWebhookRequest;
exports.isStopWebhookRequest = isStopWebhookRequest;
exports.isServerRegistrationWebhookRequest = isServerRegistrationWebhookRequest;
exports.isSessionRecoveryWebhookRequest = isSessionRecoveryWebhookRequest;
exports.isServerHeartbeatWebhookRequest = isServerHeartbeatWebhookRequest;
/**
 * Types of webhook requests that can be sent to TPAs
 */
var WebhookRequestType;
(function (WebhookRequestType) {
    /** Request to start a TPA session */
    WebhookRequestType["SESSION_REQUEST"] = "session_request";
    /** Request to stop a TPA session */
    WebhookRequestType["STOP_REQUEST"] = "stop_request";
    /** Server registration confirmation */
    WebhookRequestType["SERVER_REGISTRATION"] = "server_registration";
    /** Server heartbeat response */
    WebhookRequestType["SERVER_HEARTBEAT"] = "server_heartbeat";
    /** Session recovery request */
    WebhookRequestType["SESSION_RECOVERY"] = "session_recovery";
})(WebhookRequestType || (exports.WebhookRequestType = WebhookRequestType = {}));
/**
 * Type guard to check if a webhook request is a session request
 */
function isSessionWebhookRequest(request) {
    return request.type === WebhookRequestType.SESSION_REQUEST;
}
/**
 * Type guard to check if a webhook request is a stop request
 */
function isStopWebhookRequest(request) {
    return request.type === WebhookRequestType.STOP_REQUEST;
}
/**
 * Type guard to check if a webhook request is a server registration request
 */
function isServerRegistrationWebhookRequest(request) {
    return request.type === WebhookRequestType.SERVER_REGISTRATION;
}
/**
 * Type guard to check if a webhook request is a session recovery request
 */
function isSessionRecoveryWebhookRequest(request) {
    return request.type === WebhookRequestType.SESSION_RECOVERY;
}
/**
 * Type guard to check if a webhook request is a server heartbeat request
 */
function isServerHeartbeatWebhookRequest(request) {
    return request.type === WebhookRequestType.SERVER_HEARTBEAT;
}
