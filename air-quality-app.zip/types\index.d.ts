export * from './token';
export * from './message-types';
export * from './messages/base';
export * from './messages/glasses-to-cloud';
export * from './messages/cloud-to-glasses';
export * from './messages/tpa-to-cloud';
export * from './messages/cloud-to-tpa';
export * from './streams';
export * from './layouts';
export * from './dashboard';
export * from './enums';
export * from './models';
export * from './user-session';
export * from './webhooks';
export { ButtonPress, HeadPosition, GlassesBatteryUpdate, PhoneBatteryUpdate, GlassesConnectionState, LocationUpdate, CalendarEvent, Vad, PhoneNotification, NotificationDismissed, StartApp, StopApp, ConnectionInit, DashboardState, OpenDashboard, GlassesToCloudMessage, PhotoResponse, VideoStreamResponse, } from './messages/glasses-to-cloud';
export { ConnectionAck, ConnectionError, AuthError, DisplayEvent, AppStateChange, MicrophoneStateChange, CloudToGlassesMessage } from './messages/cloud-to-glasses';
export { TpaConnectionInit, TpaSubscriptionUpdate, TpaToCloudMessage } from './messages/tpa-to-cloud';
export { TpaConnectionAck, TpaConnectionError, AppStopped, SettingsUpdate, DataStream, CloudToTpaMessage, TranslationData, ToolCall } from './messages/cloud-to-tpa';
export { TextWall, DoubleTextWall, DashboardCard, ReferenceCard, Layout, DisplayRequest } from './layouts';
export { isButtonPress, isHeadPosition, isConnectionInit, isStartApp, isStopApp } from './messages/glasses-to-cloud';
export { isConnectionAck, isDisplayEvent, isAppStateChange, isPhotoRequest, isVideoStreamRequest } from './messages/cloud-to-glasses';
export { isTpaConnectionInit, isTpaSubscriptionUpdate, isDisplayRequest } from './messages/tpa-to-cloud';
export { isTpaConnectionAck, isDataStream, isAppStopped, isSettingsUpdate } from './messages/cloud-to-tpa';
export { BaseAppSetting, GroupSetting, TpaConfig, validateTpaConfig, ToolSchema, ToolParameterSchema } from './models';
/**
 * WebSocket error information
 */
export interface WebSocketError {
    code: string;
    message: string;
    details?: unknown;
}
import { Request } from 'express';
export interface AuthenticatedRequest extends Request {
    authUserId?: string;
}
//# sourceMappingURL=index.d.ts.map