/**
 * Constants for the SDK
 */
/**
 * System app definitions
 */
export declare const systemApps: {
    dashboard: {
        name: string;
        packageName: string;
        isSystemApp: boolean;
    };
    captions: {
        name: string;
        packageName: string;
        isSystemApp: boolean;
    };
    notifications: {
        name: string;
        packageName: string;
        isSystemApp: boolean;
    };
};
//# sourceMappingURL=index.d.ts.map