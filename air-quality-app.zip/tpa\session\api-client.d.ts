/**
 * 🔌 API Client Module
 *
 * Provides HTTP API access to AugmentOS Cloud services.
 * Automatically uses the correct server URL derived from the WebSocket URL.
 */
/**
 * Convert a WebSocket URL to a HTTP/HTTPS URL
 *
 * @param wsUrl WebSocket URL to convert
 * @returns HTTP URL equivalent
 */
export declare function wsUrlToHttpUrl(wsUrl?: string): string | undefined;
/**
 * API client class for making HTTP requests to AugmentOS Cloud
 */
export declare class ApiClient {
    private baseUrl;
    private packageName;
    private userId;
    /**
     * Create a new API client
     *
     * @param packageName TPA package name
     * @param wsUrl WebSocket URL (optional, can be set later)
     * @param userId User ID (optional, for authenticated requests)
     */
    constructor(packageName: string, wsUrl?: string, userId?: string);
    /**
     * Set the WebSocket URL to derive the HTTP base URL
     *
     * @param wsUrl WebSocket URL
     */
    setWebSocketUrl(wsUrl: string): void;
    /**
     * Set the user ID for authenticated requests
     *
     * @param userId User ID
     */
    setUserId(userId: string): void;
    /**
     * Fetch settings from AugmentOS Cloud
     *
     * @returns Promise resolving to settings array
     * @throws Error if client is not configured correctly or if request fails
     */
    fetchSettings(): Promise<any[]>;
}
//# sourceMappingURL=api-client.d.ts.map