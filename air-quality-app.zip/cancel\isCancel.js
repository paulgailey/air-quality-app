'use strict';

export default function isCancel(value) {
  return !!(value && value.__CANCEL__);
}
