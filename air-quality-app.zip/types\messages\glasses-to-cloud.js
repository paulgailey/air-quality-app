"use strict";
// src/messages/glasses-to-cloud.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.isControlAction = isControlAction;
exports.isEvent = isEvent;
exports.isConnectionInit = isConnectionInit;
exports.isRequestSettings = isRequestSettings;
exports.isStartApp = isStartApp;
exports.isStopApp = isStopApp;
exports.isButtonPress = isButtonPress;
exports.isHeadPosition = isHeadPosition;
exports.isGlassesBatteryUpdate = isGlassesBatteryUpdate;
exports.isPhoneBatteryUpdate = isPhoneBatteryUpdate;
exports.isGlassesConnectionState = isGlassesConnectionState;
exports.isLocationUpdate = isLocationUpdate;
exports.isCalendarEvent = isCalendarEvent;
exports.isVad = isVad;
exports.isPhoneNotification = isPhoneNotification;
exports.isNotificationDismissed = isNotificationDismissed;
const message_types_1 = require("../message-types");
//===========================================================
// Type guards
//===========================================================
function isControlAction(message) {
    return message_types_1.ControlActionTypes.includes(message.type);
}
function isEvent(message) {
    return message_types_1.EventTypes.includes(message.type);
}
// Individual type guards
function isConnectionInit(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.CONNECTION_INIT;
}
function isRequestSettings(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.REQUEST_SETTINGS;
}
function isStartApp(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.START_APP;
}
function isStopApp(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.STOP_APP;
}
function isButtonPress(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.BUTTON_PRESS;
}
function isHeadPosition(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.HEAD_POSITION;
}
function isGlassesBatteryUpdate(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.GLASSES_BATTERY_UPDATE;
}
function isPhoneBatteryUpdate(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.PHONE_BATTERY_UPDATE;
}
function isGlassesConnectionState(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.GLASSES_CONNECTION_STATE;
}
function isLocationUpdate(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.LOCATION_UPDATE;
}
function isCalendarEvent(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.CALENDAR_EVENT;
}
function isVad(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.VAD;
}
function isPhoneNotification(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.PHONE_NOTIFICATION;
}
function isNotificationDismissed(message) {
    return message.type === message_types_1.GlassesToCloudMessageType.NOTIFICATION_DISMISSED;
}
