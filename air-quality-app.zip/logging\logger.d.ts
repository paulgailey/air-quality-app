export declare const logger: import("pino").Logger<never, boolean>;
//# sourceMappingURL=logger.d.ts.map