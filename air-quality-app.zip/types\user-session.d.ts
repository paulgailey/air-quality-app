import { WebSocket } from 'ws';
import { AppI, AppSettings, TranscriptI } from './models';
import { AppState, Language } from './enums';
import { DisplayRequest } from './layouts';
import { Transform } from 'stream';
import { ConversationTranscriber, PushAudioInputStream } from 'microsoft-cognitiveservices-speech-sdk';
import { ExtendedStreamType, StreamType } from './streams';
import winston from 'winston';
/**
 * Session for an application
 */
export interface AppSessionI {
    userId: string;
    packageName: string;
    state: AppState;
    subscriptions: string[];
    translateToLanguages?: Language[];
    translationConfig?: {
        preserveFormatting?: boolean;
        profanityFilter?: boolean;
        contextLength?: number;
    };
    endedAt?: Date;
    disconnectedAt?: Date;
    websocket?: WebSocket;
}
/**
 * Audio processor configuration
 */
export interface AudioProcessorConfig {
    threshold: number;
    ratio: number;
    attack: number;
    release: number;
    gainDb: number;
    sampleRate: number;
    channels: number;
}
/**
 * Audio processor interface
 */
export interface AudioProcessorI extends Transform {
}
/**
 * The display manager interface
 */
export interface DisplayManagerI {
    handleDisplayEvent(displayRequest: DisplayRequest, userSession: UserSession): boolean;
    handleAppStart(packageName: string, userSession: UserSession): void;
    handleAppStop(packageName: string, userSession: UserSession): void;
}
/**
 * Currently active display
 */
export interface ActiveDisplay {
    displayRequest: DisplayRequest;
    startedAt: Date;
    expiresAt?: Date;
}
/**
 * User session with glasses client
 */
export interface UserSession {
    sessionId: string;
    userId: string;
    startTime: Date;
    disconnectedAt: Date | null;
    logger: winston.Logger;
    installedApps: AppI[];
    activeAppSessions: string[];
    loadingApps: Set<string>;
    appSubscriptions: Map<string, ExtendedStreamType[]> | Object;
    appConnections: Map<string, WebSocket>;
    displayManager: DisplayManagerI;
    websocket: WebSocket;
    transcript: TranscriptI;
    pushStream?: PushAudioInputStream;
    recognizer?: ConversationTranscriber;
    isTranscribing: boolean;
    lastAudioTimestamp?: number;
    isGracefullyClosing?: boolean;
    bufferedAudio: ArrayBufferLike[];
    audioProcessor?: AudioProcessorI;
    isAudioProcessing?: boolean;
    whatToStream: ExtendedStreamType[];
}
/**
 * App session within a user session
 */
export interface AppSession {
    packageName: string;
    userId: string;
    subscriptions: StreamType[];
    settings: AppSettings;
    websocket?: WebSocket;
    state: AppState;
    startTime: Date;
    lastActiveTime: Date;
}
//# sourceMappingURL=user-session.d.ts.map