import _FormData from 'form-data';
export default typeof FormData !== 'undefined' ? FormData : _FormData;
