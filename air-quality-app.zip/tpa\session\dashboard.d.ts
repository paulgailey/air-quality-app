import { DashboardAPI, DashboardContentAPI, DashboardMode, DashboardSystemAPI } from '../../types/dashboard';
import { EventManager } from './events';
import type { TpaSession } from './index';
import { TpaToCloudMessage } from 'src/types';
/**
 * Implementation of DashboardSystemAPI interface for system dashboard TPA
 */
export declare class DashboardSystemManager implements DashboardSystemAPI {
    private session;
    private packageName;
    private send;
    constructor(session: TpaSession, packageName: string, send: (message: any) => void);
    setTopLeft(content: string): void;
    setTopRight(content: string): void;
    setBottomLeft(content: string): void;
    setBottomRight(content: string): void;
    setViewMode(mode: DashboardMode): void;
    private updateSystemSection;
}
/**
 * Implementation of DashboardContentAPI interface for all TPAs
 */
export declare class DashboardContentManager implements DashboardContentAPI {
    private session;
    private packageName;
    private send;
    private events;
    private currentMode;
    constructor(session: TpaSession, packageName: string, send: (message: any) => void, events: EventManager);
    write(content: string, targets?: DashboardMode[]): void;
    writeToMain(content: string): void;
    writeToExpanded(content: string): void;
    getCurrentMode(): Promise<DashboardMode | 'none'>;
    onModeChange(callback: (mode: DashboardMode | 'none') => void): () => void;
    setCurrentMode(mode: DashboardMode | 'none'): void;
}
/**
 * Dashboard Manager - Main class that manages dashboard functionality
 * Each TpaSession instance gets its own DashboardManager instance
 */
export declare class DashboardManager implements DashboardAPI {
    readonly content: DashboardContentAPI;
    readonly system?: DashboardSystemAPI;
    constructor(session: TpaSession, send: (message: TpaToCloudMessage) => void);
}
//# sourceMappingURL=dashboard.d.ts.map