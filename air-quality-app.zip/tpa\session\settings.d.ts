import { AppSetting, AppSettings } from '../../types';
/**
 * Change information for a single setting
 */
export interface SettingChange {
    oldValue: any;
    newValue: any;
}
/**
 * Map of setting keys to their change information
 */
export type SettingsChangeMap = Record<string, SettingChange>;
/**
 * Callback for when any setting changes
 */
export type SettingsChangeHandler = (changes: SettingsChangeMap) => void;
/**
 * Callback for when a specific setting changes
 */
export type SettingValueChangeHandler<T = any> = (newValue: T, oldValue: T) => void;
/**
 * 🔧 Settings Manager
 *
 * Provides a type-safe interface for accessing and reacting to TPA settings.
 * Automatically synchronizes with AugmentOS Cloud.
 */
export declare class SettingsManager {
    private settings;
    private emitter;
    private apiClient?;
    private augmentosSettings;
    private augmentosEmitter;
    private subscribeFn?;
    /**
     * Create a new settings manager
     *
     * @param initialSettings Initial settings values (if available)
     * @param packageName Package name for the TPA
     * @param wsUrl WebSocket URL (for deriving HTTP API URL)
     * @param userId User ID (for authenticated requests)
     * @param subscribeFn Optional function to call to subscribe to streams
     */
    constructor(initialSettings?: AppSettings, packageName?: string, wsUrl?: string, userId?: string, subscribeFn?: (streams: string[]) => Promise<void>);
    /**
     * Configure the API client
     *
     * @param packageName Package name for the TPA
     * @param wsUrl WebSocket URL
     * @param userId User ID
     */
    configureApiClient(packageName: string, wsUrl: string, userId: string): void;
    /**
     * Update the current settings
     * This is called internally when settings are loaded or changed
     *
     * @param newSettings New settings values
     * @returns Map of changed settings
     */
    updateSettings(newSettings: AppSettings): SettingsChangeMap;
    /**
     * Check if two setting values are equal
     *
     * @param a First value
     * @param b Second value
     * @returns True if the values are equal
     */
    private areEqual;
    /**
     * Emit change events for updated settings
     *
     * @param changes Map of changed settings
     */
    private emitChanges;
    /**
     * 🔄 Listen for changes to any setting
     *
     * @param handler Function to call when settings change
     * @returns Function to remove the listener
     *
     * @example
     * ```typescript
     * settings.onChange((changes) => {
     *   console.log('Settings changed:', changes);
     * });
     * ```
     */
    onChange(handler: SettingsChangeHandler): () => void;
    /**
     * 🔄 Listen for changes to a specific setting
     *
     * @param key Setting key to monitor
     * @param handler Function to call when the setting changes
     * @returns Function to remove the listener
     *
     * @example
     * ```typescript
     * settings.onValueChange('transcribe_language', (newValue, oldValue) => {
     *   console.log(`Language changed from ${oldValue} to ${newValue}`);
     * });
     * ```
     */
    onValueChange<T = any>(key: string, handler: SettingValueChangeHandler<T>): () => void;
    /**
     * 🔍 Check if a setting exists
     *
     * @param key Setting key to check
     * @returns True if the setting exists
     */
    has(key: string): boolean;
    /**
     * 🔍 Get all settings
     *
     * @returns Copy of all settings
     */
    getAll(): AppSettings;
    /**
     * 🔍 Get a setting value with type safety
     *
     * @param key Setting key to get
     * @param defaultValue Default value if setting doesn't exist or is undefined
     * @returns Setting value or default value
     *
     * @example
     * ```typescript
     * const lineWidth = settings.get<number>('line_width', 30);
     * const language = settings.get<string>('transcribe_language', 'English');
     * ```
     */
    get<T = any>(key: string, defaultValue?: T): T;
    /**
     * 🔍 Find a setting by key
     *
     * @param key Setting key to find
     * @returns Setting object or undefined
     */
    getSetting(key: string): AppSetting | undefined;
    /**
     * 🔄 Fetch settings from the cloud
     * This is generally not needed since settings are automatically kept in sync,
     * but can be used to force a refresh if needed.
     *
     * @returns Promise that resolves to the updated settings
     * @throws Error if the API client is not configured or the request fails
     */
    fetch(): Promise<AppSettings>;
    /**
     * Listen for changes to a specific AugmentOS setting (e.g., metricSystemEnabled)
     * This is a convenience wrapper for onValueChange for well-known augmentosSettings keys.
     * @param key The augmentosSettings key to listen for (e.g., 'metricSystemEnabled')
     * @param handler Function to call when the value changes
     * @returns Function to remove the listener
     */
    onAugmentosSettingsChange<T = any>(key: string, handler: SettingValueChangeHandler<T>): () => void;
    /**
     * Update the current AugmentOS settings
     * Compares new and old values, emits per-key events, and updates stored values.
     * @param newSettings The new AugmentOS settings object
     */
    updateAugmentosSettings(newSettings: Record<string, any>): void;
    /**
     * Subscribe to changes for a specific AugmentOS setting (e.g., 'metricSystemEnabled')
     * @param key The AugmentOS setting key to listen for
     * @param handler Function to call when the value changes (newValue, oldValue)
     * @returns Function to remove the listener
     */
    onAugmentosSettingChange<T = any>(key: string, handler: (newValue: T, oldValue: T) => void): () => void;
    /**
     * Get the current value of an AugmentOS setting
     */
    getAugmentosSetting<T = any>(key: string, defaultValue?: T): T;
}
//# sourceMappingURL=settings.d.ts.map