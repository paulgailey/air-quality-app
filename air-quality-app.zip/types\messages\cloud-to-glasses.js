"use strict";
// src/messages/cloud-to-glasses.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.isResponse = isResponse;
exports.isUpdate = isUpdate;
exports.isConnectionAck = isConnectionAck;
exports.isConnectionError = isConnectionError;
exports.isAuthError = isAuthError;
exports.isDisplayEvent = isDisplayEvent;
exports.isAppStateChange = isAppStateChange;
exports.isMicrophoneStateChange = isMicrophoneStateChange;
exports.isPhotoRequest = isPhotoRequest;
exports.isVideoStreamRequest = isVideoStreamRequest;
const message_types_1 = require("../message-types");
//===========================================================
// Type guards
//===========================================================
function isResponse(message) {
    return message_types_1.ResponseTypes.includes(message.type);
}
function isUpdate(message) {
    return message_types_1.UpdateTypes.includes(message.type);
}
// Individual type guards
function isConnectionAck(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.CONNECTION_ACK;
}
function isConnectionError(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.CONNECTION_ERROR;
}
function isAuthError(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.AUTH_ERROR;
}
function isDisplayEvent(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.DISPLAY_EVENT;
}
function isAppStateChange(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.APP_STATE_CHANGE;
}
function isMicrophoneStateChange(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.MICROPHONE_STATE_CHANGE;
}
function isPhotoRequest(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.PHOTO_REQUEST;
}
function isVideoStreamRequest(message) {
    return message.type === message_types_1.CloudToGlassesMessageType.VIDEO_STREAM_REQUEST;
}
