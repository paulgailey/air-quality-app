/**
 * Types of messages from glasses to cloud
 */
export declare enum GlassesToCloudMessageType {
    CONNECTION_INIT = "connection_init",
    REQUEST_SETTINGS = "request_settings",
    START_APP = "start_app",
    STOP_APP = "stop_app",
    DASHBOARD_STATE = "dashboard_state",
    OPEN_DASHBOARD = "open_dashboard",
    PHOTO_RESPONSE = "photo_response",
    VIDEO_STREAM_RESPONSE = "video_stream_response",
    BUTTON_PRESS = "button_press",
    HEAD_POSITION = "head_position",
    GLASSES_BATTERY_UPDATE = "glasses_battery_update",
    PHONE_BATTERY_UPDATE = "phone_battery_update",
    GLASSES_CONNECTION_STATE = "glasses_connection_state",
    LOCATION_UPDATE = "location_update",
    VAD = "VAD",
    PHONE_NOTIFICATION = "phone_notification",
    NOTIFICATION_DISMISSED = "notification_dismissed",
    CALENDAR_EVENT = "calendar_event",
    AUGMENTOS_SETTINGS_UPDATE_REQUEST = "settings_update_request",
    CORE_STATUS_UPDATE = "core_status_update"
}
/**
 * Types of messages from cloud to glasses
 */
export declare enum CloudToGlassesMessageType {
    CONNECTION_ACK = "connection_ack",
    CONNECTION_ERROR = "connection_error",
    AUTH_ERROR = "auth_error",
    DISPLAY_EVENT = "display_event",
    APP_STATE_CHANGE = "app_state_change",
    MICROPHONE_STATE_CHANGE = "microphone_state_change",
    PHOTO_REQUEST = "photo_request",
    VIDEO_STREAM_REQUEST = "video_stream_request",
    SETTINGS_UPDATE = "settings_update",
    DASHBOARD_MODE_CHANGE = "dashboard_mode_change",
    DASHBOARD_ALWAYS_ON_CHANGE = "dashboard_always_on_change",
    WEBSOCKET_ERROR = "websocket_error"
}
/**
 * Types of messages from TPAs to cloud
 */
export declare enum TpaToCloudMessageType {
    CONNECTION_INIT = "tpa_connection_init",
    SUBSCRIPTION_UPDATE = "subscription_update",
    DISPLAY_REQUEST = "display_event",
    PHOTO_REQUEST = "photo_request",
    VIDEO_STREAM_REQUEST = "video_stream_request",
    DASHBOARD_CONTENT_UPDATE = "dashboard_content_update",
    DASHBOARD_MODE_CHANGE = "dashboard_mode_change",
    DASHBOARD_SYSTEM_UPDATE = "dashboard_system_update"
}
/**
 * Types of messages from cloud to TPAs
 */
export declare enum CloudToTpaMessageType {
    CONNECTION_ACK = "tpa_connection_ack",
    CONNECTION_ERROR = "tpa_connection_error",
    APP_STOPPED = "app_stopped",
    SETTINGS_UPDATE = "settings_update",
    DASHBOARD_MODE_CHANGED = "dashboard_mode_changed",
    DASHBOARD_ALWAYS_ON_CHANGED = "dashboard_always_on_changed",
    DATA_STREAM = "data_stream",
    PHOTO_RESPONSE = "photo_response",
    VIDEO_STREAM_RESPONSE = "video_stream_response",
    WEBSOCKET_ERROR = "websocket_error",
    CUSTOM_MESSAGE = "custom_message"
}
/**
 * Control action message types (subset of GlassesToCloudMessageType)
 */
export declare const ControlActionTypes: readonly [GlassesToCloudMessageType.CONNECTION_INIT, GlassesToCloudMessageType.START_APP, GlassesToCloudMessageType.STOP_APP, GlassesToCloudMessageType.DASHBOARD_STATE, GlassesToCloudMessageType.OPEN_DASHBOARD];
/**
 * Event message types (subset of GlassesToCloudMessageType)
 */
export declare const EventTypes: readonly [GlassesToCloudMessageType.BUTTON_PRESS, GlassesToCloudMessageType.HEAD_POSITION, GlassesToCloudMessageType.GLASSES_BATTERY_UPDATE, GlassesToCloudMessageType.PHONE_BATTERY_UPDATE, GlassesToCloudMessageType.GLASSES_CONNECTION_STATE, GlassesToCloudMessageType.LOCATION_UPDATE, GlassesToCloudMessageType.VAD, GlassesToCloudMessageType.PHONE_NOTIFICATION, GlassesToCloudMessageType.NOTIFICATION_DISMISSED, GlassesToCloudMessageType.CALENDAR_EVENT, GlassesToCloudMessageType.AUGMENTOS_SETTINGS_UPDATE_REQUEST, GlassesToCloudMessageType.CORE_STATUS_UPDATE];
/**
 * Response message types (subset of CloudToGlassesMessageType)
 */
export declare const ResponseTypes: readonly [CloudToGlassesMessageType.CONNECTION_ACK, CloudToGlassesMessageType.CONNECTION_ERROR, CloudToGlassesMessageType.AUTH_ERROR];
/**
 * Update message types (subset of CloudToGlassesMessageType)
 */
export declare const UpdateTypes: readonly [CloudToGlassesMessageType.DISPLAY_EVENT, CloudToGlassesMessageType.APP_STATE_CHANGE, CloudToGlassesMessageType.MICROPHONE_STATE_CHANGE, CloudToGlassesMessageType.PHOTO_REQUEST, CloudToGlassesMessageType.VIDEO_STREAM_REQUEST, CloudToGlassesMessageType.SETTINGS_UPDATE, CloudToGlassesMessageType.DASHBOARD_MODE_CHANGE, CloudToGlassesMessageType.DASHBOARD_ALWAYS_ON_CHANGE];
/**
 * Dashboard message types
 */
export declare const DashboardMessageTypes: readonly [TpaToCloudMessageType.DASHBOARD_CONTENT_UPDATE, TpaToCloudMessageType.DASHBOARD_MODE_CHANGE, TpaToCloudMessageType.DASHBOARD_SYSTEM_UPDATE, CloudToTpaMessageType.DASHBOARD_MODE_CHANGED, CloudToTpaMessageType.DASHBOARD_ALWAYS_ON_CHANGED];
//# sourceMappingURL=message-types.d.ts.map