"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardManager = exports.DashboardContentManager = exports.DashboardSystemManager = void 0;
/**
 * Dashboard API Implementation
 *
 * Provides dashboard functionality for TPAs, allowing them to write content
 * to the dashboard and respond to dashboard mode changes.
 */
const constants_1 = require("../../constants");
const dashboard_1 = require("../../types/dashboard");
const message_types_1 = require("../../types/message-types");
/**
 * Implementation of DashboardSystemAPI interface for system dashboard TPA
 */
class DashboardSystemManager {
    constructor(session, packageName, send) {
        this.session = session;
        this.packageName = packageName;
        this.send = send;
    }
    setTopLeft(content) {
        this.updateSystemSection('topLeft', content);
    }
    setTopRight(content) {
        this.updateSystemSection('topRight', content);
    }
    setBottomLeft(content) {
        this.updateSystemSection('bottomLeft', content);
    }
    setBottomRight(content) {
        this.updateSystemSection('bottomRight', content);
    }
    setViewMode(mode) {
        const message = {
            type: message_types_1.TpaToCloudMessageType.DASHBOARD_MODE_CHANGE,
            packageName: this.packageName,
            sessionId: `${this.session.getSessionId()}-${this.packageName}`,
            mode,
            timestamp: new Date()
        };
        this.send(message);
    }
    updateSystemSection(section, content) {
        const message = {
            type: message_types_1.TpaToCloudMessageType.DASHBOARD_SYSTEM_UPDATE,
            packageName: this.packageName,
            sessionId: `${this.session.getSessionId()}-${this.packageName}`,
            section,
            content,
            timestamp: new Date()
        };
        this.send(message);
    }
}
exports.DashboardSystemManager = DashboardSystemManager;
/**
 * Implementation of DashboardContentAPI interface for all TPAs
 */
class DashboardContentManager {
    // private alwaysOnEnabled: boolean = false;
    constructor(session, packageName, send, events) {
        this.session = session;
        this.packageName = packageName;
        this.send = send;
        this.events = events;
        this.currentMode = 'none';
    }
    write(content, targets = [dashboard_1.DashboardMode.MAIN]) {
        const message = {
            type: message_types_1.TpaToCloudMessageType.DASHBOARD_CONTENT_UPDATE,
            packageName: this.packageName,
            sessionId: `${this.session.getSessionId()}-${this.packageName}`,
            content,
            modes: targets,
            timestamp: new Date()
        };
        this.send(message);
    }
    writeToMain(content) {
        this.write(content, [dashboard_1.DashboardMode.MAIN]);
    }
    writeToExpanded(content) {
        const message = {
            type: message_types_1.TpaToCloudMessageType.DASHBOARD_CONTENT_UPDATE,
            packageName: this.packageName,
            sessionId: `${this.session.getSessionId()}-${this.packageName}`,
            content,
            modes: [dashboard_1.DashboardMode.EXPANDED],
            timestamp: new Date()
        };
        this.send(message);
    }
    // writeToAlwaysOn(content: string): void {
    //   this.write(content, [DashboardMode.ALWAYS_ON]);
    // }
    async getCurrentMode() {
        return this.currentMode;
    }
    // async isAlwaysOnEnabled(): Promise<boolean> {
    //   return this.alwaysOnEnabled;
    // }
    onModeChange(callback) {
        return this.events.onDashboardModeChange((data) => {
            this.currentMode = data.mode;
            callback(data.mode);
        });
    }
    // onAlwaysOnChange(callback: (enabled: boolean) => void): () => void {
    //   return this.events.onDashboardAlwaysOnChange((data) => {
    //     this.alwaysOnEnabled = data.enabled;
    //     callback(data.enabled);
    //   });
    // }
    // Internal methods to update state
    setCurrentMode(mode) {
        this.currentMode = mode;
        this.events.emit('dashboard_mode_change', { mode });
    }
}
exports.DashboardContentManager = DashboardContentManager;
/**
 * Dashboard Manager - Main class that manages dashboard functionality
 * Each TpaSession instance gets its own DashboardManager instance
 */
class DashboardManager {
    constructor(session, send) {
        const packageName = session.getPackageName();
        const events = session.events;
        // Create content API (available to all TPAs)
        this.content = new DashboardContentManager(session, packageName, send, events);
        // Add system API if this is the system dashboard TPA
        if (packageName === constants_1.systemApps.dashboard.packageName) {
            this.system = new DashboardSystemManager(session, packageName, send);
        }
    }
}
exports.DashboardManager = DashboardManager;
