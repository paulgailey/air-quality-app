import { BaseMessage } from './base';
import { TpaToCloudMessageType } from '../message-types';
import { ExtendedStreamType } from '../streams';
import { DisplayRequest } from '../layouts';
import { DashboardContentUpdate, DashboardModeChange, DashboardSystemUpdate } from '../dashboard';
/**
 * Connection initialization from TPA
 */
export interface TpaConnectionInit extends BaseMessage {
    type: TpaToCloudMessageType.CONNECTION_INIT;
    packageName: string;
    sessionId: string;
    apiKey: string;
}
/**
 * Subscription update from TPA
 */
export interface TpaSubscriptionUpdate extends BaseMessage {
    type: TpaToCloudMessageType.SUBSCRIPTION_UPDATE;
    packageName: string;
    subscriptions: ExtendedStreamType[];
}
/**
 * Photo request from TPA
 */
export interface PhotoRequest extends BaseMessage {
    type: TpaToCloudMessageType.PHOTO_REQUEST;
    packageName: string;
    saveToGallery?: boolean;
}
/**
 * Video stream request from TPA
 */
export interface VideoStreamRequest extends BaseMessage {
    type: TpaToCloudMessageType.VIDEO_STREAM_REQUEST;
    packageName: string;
}
/**
 * Union type for all messages from TPAs to cloud
 */
export type TpaToCloudMessage = TpaConnectionInit | TpaSubscriptionUpdate | DisplayRequest | PhotoRequest | VideoStreamRequest | DashboardContentUpdate | DashboardModeChange | DashboardSystemUpdate;
/**
 * Type guard to check if a message is a TPA connection init
 */
export declare function isTpaConnectionInit(message: TpaToCloudMessage): message is TpaConnectionInit;
/**
 * Type guard to check if a message is a TPA subscription update
 */
export declare function isTpaSubscriptionUpdate(message: TpaToCloudMessage): message is TpaSubscriptionUpdate;
/**
 * Type guard to check if a message is a TPA display request
 */
export declare function isDisplayRequest(message: TpaToCloudMessage): message is DisplayRequest;
/**
 * Type guard to check if a message is a TPA photo request
 */
export declare function isPhotoRequest(message: TpaToCloudMessage): message is PhotoRequest;
/**
 * Type guard to check if a message is a TPA video stream request
 */
export declare function isVideoStreamRequest(message: TpaToCloudMessage): message is VideoStreamRequest;
/**
 * Type guard to check if a message is a dashboard content update
 */
export declare function isDashboardContentUpdate(message: TpaToCloudMessage): message is DashboardContentUpdate;
/**
 * Type guard to check if a message is a dashboard mode change
 */
export declare function isDashboardModeChange(message: TpaToCloudMessage): message is DashboardModeChange;
/**
 * Type guard to check if a message is a dashboard system update
 */
export declare function isDashboardSystemUpdate(message: TpaToCloudMessage): message is DashboardSystemUpdate;
//# sourceMappingURL=tpa-to-cloud.d.ts.map