import { BaseMessage } from './base';
import { GlassesToCloudMessageType } from '../message-types';
import { StreamType } from '../streams';
/**
 * Connection initialization from glasses
 */
export interface ConnectionInit extends BaseMessage {
    type: GlassesToCloudMessageType.CONNECTION_INIT;
    userId?: string;
    coreToken?: string;
}
export interface RequestSettings extends BaseMessage {
    type: GlassesToCloudMessageType.REQUEST_SETTINGS;
    sessionId: string;
}
/**
 * Start app request from glasses
 */
export interface StartApp extends BaseMessage {
    type: GlassesToCloudMessageType.START_APP;
    packageName: string;
}
/**
 * Stop app request from glasses
 */
export interface StopApp extends BaseMessage {
    type: GlassesToCloudMessageType.STOP_APP;
    packageName: string;
}
/**
 * Dashboard state update from glasses
 */
export interface DashboardState extends BaseMessage {
    type: GlassesToCloudMessageType.DASHBOARD_STATE;
    isOpen: boolean;
}
/**
 * Open dashboard request from glasses
 */
export interface OpenDashboard extends BaseMessage {
    type: GlassesToCloudMessageType.OPEN_DASHBOARD;
}
/**
 * Button press event from glasses
 */
export interface ButtonPress extends BaseMessage {
    type: GlassesToCloudMessageType.BUTTON_PRESS;
    buttonId: string;
    pressType: 'short' | 'long';
}
/**
 * Head position event from glasses
 */
export interface HeadPosition extends BaseMessage {
    type: GlassesToCloudMessageType.HEAD_POSITION;
    position: 'up' | 'down';
}
/**
 * Glasses battery update from glasses
 */
export interface GlassesBatteryUpdate extends BaseMessage {
    type: GlassesToCloudMessageType.GLASSES_BATTERY_UPDATE;
    level: number;
    charging: boolean;
    timeRemaining?: number;
}
/**
 * Phone battery update from glasses
 */
export interface PhoneBatteryUpdate extends BaseMessage {
    type: GlassesToCloudMessageType.PHONE_BATTERY_UPDATE;
    level: number;
    charging: boolean;
    timeRemaining?: number;
}
/**
 * Glasses connection state from glasses
 */
export interface GlassesConnectionState extends BaseMessage {
    type: GlassesToCloudMessageType.GLASSES_CONNECTION_STATE;
    modelName: string;
    status: string;
}
/**
 * Location update from glasses
 */
export interface LocationUpdate extends BaseMessage {
    type: GlassesToCloudMessageType.LOCATION_UPDATE | StreamType.LOCATION_UPDATE;
    lat: number;
    lng: number;
}
export interface CalendarEvent extends BaseMessage {
    type: GlassesToCloudMessageType.CALENDAR_EVENT | StreamType.CALENDAR_EVENT;
    eventId: string;
    title: string;
    dtStart: string;
    dtEnd: string;
    timezone: string;
    timeStamp: string;
}
/**
 * Voice activity detection from glasses
 */
export interface Vad extends BaseMessage {
    type: GlassesToCloudMessageType.VAD;
    status: boolean | "true" | "false";
}
/**
 * Phone notification from glasses
 */
export interface PhoneNotification extends BaseMessage {
    type: GlassesToCloudMessageType.PHONE_NOTIFICATION;
    notificationId: string;
    app: string;
    title: string;
    content: string;
    priority: 'low' | 'normal' | 'high';
}
/**
 * Notification dismissed from glasses
 */
export interface NotificationDismissed extends BaseMessage {
    type: GlassesToCloudMessageType.NOTIFICATION_DISMISSED;
    notificationId: string;
}
/**
 * AugmentOS settings update from glasses
 */
export interface AugmentosSettingsUpdateRequest extends BaseMessage {
    type: GlassesToCloudMessageType.AUGMENTOS_SETTINGS_UPDATE_REQUEST;
}
/**
 * Core status update from glasses
 */
export interface CoreStatusUpdate extends BaseMessage {
    type: GlassesToCloudMessageType.CORE_STATUS_UPDATE;
    status: string;
    details?: Record<string, any>;
}
export interface PhotoResponse extends BaseMessage {
    type: GlassesToCloudMessageType.PHOTO_RESPONSE;
    requestId: string;
    photoUrl: string;
    savedToGallery: boolean;
}
export interface VideoStreamResponse extends BaseMessage {
    type: GlassesToCloudMessageType.VIDEO_STREAM_RESPONSE;
    requestId: string;
    videoUrl: string;
    savedToGallery: boolean;
}
/**
 * Union type for all messages from glasses to cloud
 */
export type GlassesToCloudMessage = ConnectionInit | RequestSettings | StartApp | StopApp | DashboardState | OpenDashboard | ButtonPress | HeadPosition | GlassesBatteryUpdate | PhoneBatteryUpdate | GlassesConnectionState | LocationUpdate | CalendarEvent | Vad | PhoneNotification | NotificationDismissed | AugmentosSettingsUpdateRequest | CoreStatusUpdate | PhotoResponse | VideoStreamResponse;
export declare function isControlAction(message: GlassesToCloudMessage): boolean;
export declare function isEvent(message: GlassesToCloudMessage): boolean;
export declare function isConnectionInit(message: GlassesToCloudMessage): message is ConnectionInit;
export declare function isRequestSettings(message: GlassesToCloudMessage): message is RequestSettings;
export declare function isStartApp(message: GlassesToCloudMessage): message is StartApp;
export declare function isStopApp(message: GlassesToCloudMessage): message is StopApp;
export declare function isButtonPress(message: GlassesToCloudMessage): message is ButtonPress;
export declare function isHeadPosition(message: GlassesToCloudMessage): message is HeadPosition;
export declare function isGlassesBatteryUpdate(message: GlassesToCloudMessage): message is GlassesBatteryUpdate;
export declare function isPhoneBatteryUpdate(message: GlassesToCloudMessage): message is PhoneBatteryUpdate;
export declare function isGlassesConnectionState(message: GlassesToCloudMessage): message is GlassesConnectionState;
export declare function isLocationUpdate(message: GlassesToCloudMessage): message is LocationUpdate;
export declare function isCalendarEvent(message: GlassesToCloudMessage): message is CalendarEvent;
export declare function isVad(message: GlassesToCloudMessage): message is Vad;
export declare function isPhoneNotification(message: GlassesToCloudMessage): message is PhoneNotification;
export declare function isNotificationDismissed(message: GlassesToCloudMessage): message is NotificationDismissed;
//# sourceMappingURL=glasses-to-cloud.d.ts.map