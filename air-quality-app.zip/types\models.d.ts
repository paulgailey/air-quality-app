import { AppSettingType, TpaType } from './enums';
export interface ToolParameterSchema {
    type: 'string' | 'number' | 'boolean';
    description: string;
    enum?: string[];
    required?: boolean;
}
export interface ToolSchema {
    id: string;
    description: string;
    activationPhrases?: string[];
    parameters?: Record<string, ToolParameterSchema>;
}
/**
 * Developer profile information
 */
export interface DeveloperProfile {
    company?: string;
    website?: string;
    contactEmail?: string;
    description?: string;
    logo?: string;
}
export declare enum PermissionType {
    MICROPHONE = "MICROPHONE",
    LOCATION = "LOCATION",
    CALENDAR = "CALENDAR",
    NOTIFICATIONS = "NOTIFICATIONS",
    ALL = "ALL"
}
export interface Permission {
    type: PermissionType;
    description?: string;
}
/**
 * Base interface for applications
 */
export interface AppI {
    packageName: string;
    name: string;
    publicUrl: string;
    isSystemApp?: boolean;
    uninstallable?: boolean;
    webviewURL?: string;
    logoURL: string;
    tpaType: TpaType;
    appStoreId?: string;
    developerId?: string;
    hashedEndpointSecret?: string;
    hashedApiKey?: string;
    permissions?: Permission[];
    description?: string;
    version?: string;
    settings?: AppSettings;
    isPublic?: boolean;
    appStoreStatus?: 'DEVELOPMENT' | 'SUBMITTED' | 'REJECTED' | 'PUBLISHED';
}
/**
 * Base interface for all app settings
 */
export interface BaseAppSetting {
    key: string;
    label: string;
    value?: any;
    defaultValue?: any;
}
/**
 * Setting types for applications
 */
export type AppSetting = (BaseAppSetting & {
    type: AppSettingType.TOGGLE;
    defaultValue: boolean;
    value?: boolean;
}) | (BaseAppSetting & {
    type: AppSettingType.TEXT;
    defaultValue?: string;
    value?: string;
}) | (BaseAppSetting & {
    type: AppSettingType.SELECT;
    options: {
        label: string;
        value: any;
    }[];
    defaultValue?: any;
    value?: any;
});
export type AppSettings = AppSetting[];
/**
 * Group setting (for UI organization)
 */
export interface GroupSetting {
    type: 'group';
    title: string;
}
/**
 * TPA configuration file structure
 * Represents the schema in tpa_config.json
 */
export interface TpaConfig {
    name: string;
    description: string;
    version: string;
    settings: (AppSetting | GroupSetting)[];
}
/**
 * Validate a TPA configuration object
 * @param config Object to validate
 * @returns True if the config is valid
 */
export declare function validateTpaConfig(config: any): config is TpaConfig;
/**
 * Transcript segment for speech processing
 */
export interface TranscriptSegment {
    speakerId?: string;
    resultId: string;
    text: string;
    timestamp: Date;
    isFinal: boolean;
}
/**
 * Complete transcript
 */
export interface TranscriptI {
    segments: TranscriptSegment[];
    languageSegments?: Map<string, TranscriptSegment[]>;
}
//# sourceMappingURL=models.d.ts.map