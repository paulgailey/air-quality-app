"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createToken = createToken;
exports.validateToken = validateToken;
exports.generateWebviewUrl = generateWebviewUrl;
exports.extractTokenFromUrl = extractTokenFromUrl;
/**
 * 🔐 TPA Token Utilities
 *
 * Provides utilities for working with TPA tokens.
 */
const jwt = __importStar(require("jsonwebtoken"));
/**
 * Default token expiration (1 day)
 */
const DEFAULT_EXPIRATION = 60 * 60 * 24; // seconds * minutes * hours (1 day).
/**
 * Create a TPA token for a user session
 *
 * @param payload - Token payload data
 * @param config - Token configuration
 * @returns JWT token string
 *
 * @example
 * ```typescript
 * const token = createToken(
 *   {
 *     userId: 'user123',
 *     packageName: 'org.example.myapp',
 *     sessionId: 'session789'
 *   },
 *   { secretKey: 'your_secret_key' }
 * );
 * ```
 */
function createToken(payload, config) {
    return jwt.sign(payload, config.secretKey, { expiresIn: config.expiresIn || DEFAULT_EXPIRATION });
}
/**
 * Validate and decode a TPA token
 *
 * @param token - JWT token string
 * @param secretKey - Secret key used for validation
 * @returns Token validation result
 *
 * @example
 * ```typescript
 * const result = validateToken('eyJhbGciOiJIUzI1...', 'your_secret_key');
 * if (result.valid) {
 *   // Use result.payload
 * }
 * ```
 */
function validateToken(token, secretKey) {
    try {
        const decoded = jwt.verify(token, secretKey);
        return {
            valid: true,
            payload: decoded
        };
    }
    catch (error) {
        return {
            valid: false,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
    }
}
/**
 * Generate a webview URL with an embedded TPA token
 *
 * @param baseUrl - Base URL of the webview
 * @param token - JWT token string
 * @returns Full URL with token parameter
 *
 * @example
 * ```typescript
 * const url = generateWebviewUrl(
 *   'https://example.com/webview',
 *   'eyJhbGciOiJIUzI1...'
 * );
 * // Returns: https://example.com/webview?token=eyJhbGciOiJIUzI1...
 * ```
 */
function generateWebviewUrl(baseUrl, token) {
    const url = new URL(baseUrl);
    url.searchParams.append('token', token);
    return url.toString();
}
/**
 * Extract a TPA token from a URL
 *
 * @param url - URL string containing a token parameter
 * @returns Token string or null if not found
 *
 * @example
 * ```typescript
 * const token = extractTokenFromUrl(
 *   'https://example.com/webview?token=eyJhbGciOiJIUzI1...'
 * );
 * ```
 */
function extractTokenFromUrl(url) {
    try {
        const parsedUrl = new URL(url);
        return parsedUrl.searchParams.get('token');
    }
    catch (error) {
        return null;
    }
}
