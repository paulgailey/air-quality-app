"use strict";
// src/index.ts
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateTpaConfig = exports.isSettingsUpdate = exports.isAppStopped = exports.isDataStream = exports.isTpaConnectionAck = exports.isDisplayRequest = exports.isTpaSubscriptionUpdate = exports.isTpaConnectionInit = exports.isVideoStreamRequest = exports.isPhotoRequest = exports.isAppStateChange = exports.isDisplayEvent = exports.isConnectionAck = exports.isStopApp = exports.isStartApp = exports.isConnectionInit = exports.isHeadPosition = exports.isButtonPress = void 0;
__exportStar(require("./token"), exports);
// Message type enums
__exportStar(require("./message-types"), exports);
// Base message type
__exportStar(require("./messages/base"), exports);
// Messages by direction
__exportStar(require("./messages/glasses-to-cloud"), exports);
__exportStar(require("./messages/cloud-to-glasses"), exports);
__exportStar(require("./messages/tpa-to-cloud"), exports);
__exportStar(require("./messages/cloud-to-tpa"), exports);
// Stream types
__exportStar(require("./streams"), exports);
// Layout types
__exportStar(require("./layouts"), exports);
// Dashboard types
__exportStar(require("./dashboard"), exports);
// Other system enums
__exportStar(require("./enums"), exports);
// Core model interfaces
__exportStar(require("./models"), exports);
// Session-related interfaces
__exportStar(require("./user-session"), exports);
// Webhook interfaces
__exportStar(require("./webhooks"), exports);
// Type guards - re-export the most commonly used ones for convenience
var glasses_to_cloud_1 = require("./messages/glasses-to-cloud");
Object.defineProperty(exports, "isButtonPress", { enumerable: true, get: function () { return glasses_to_cloud_1.isButtonPress; } });
Object.defineProperty(exports, "isHeadPosition", { enumerable: true, get: function () { return glasses_to_cloud_1.isHeadPosition; } });
Object.defineProperty(exports, "isConnectionInit", { enumerable: true, get: function () { return glasses_to_cloud_1.isConnectionInit; } });
Object.defineProperty(exports, "isStartApp", { enumerable: true, get: function () { return glasses_to_cloud_1.isStartApp; } });
Object.defineProperty(exports, "isStopApp", { enumerable: true, get: function () { return glasses_to_cloud_1.isStopApp; } });
var cloud_to_glasses_1 = require("./messages/cloud-to-glasses");
Object.defineProperty(exports, "isConnectionAck", { enumerable: true, get: function () { return cloud_to_glasses_1.isConnectionAck; } });
Object.defineProperty(exports, "isDisplayEvent", { enumerable: true, get: function () { return cloud_to_glasses_1.isDisplayEvent; } });
Object.defineProperty(exports, "isAppStateChange", { enumerable: true, get: function () { return cloud_to_glasses_1.isAppStateChange; } });
Object.defineProperty(exports, "isPhotoRequest", { enumerable: true, get: function () { return cloud_to_glasses_1.isPhotoRequest; } });
Object.defineProperty(exports, "isVideoStreamRequest", { enumerable: true, get: function () { return cloud_to_glasses_1.isVideoStreamRequest; } });
var tpa_to_cloud_1 = require("./messages/tpa-to-cloud");
Object.defineProperty(exports, "isTpaConnectionInit", { enumerable: true, get: function () { return tpa_to_cloud_1.isTpaConnectionInit; } });
Object.defineProperty(exports, "isTpaSubscriptionUpdate", { enumerable: true, get: function () { return tpa_to_cloud_1.isTpaSubscriptionUpdate; } });
Object.defineProperty(exports, "isDisplayRequest", { enumerable: true, get: function () { return tpa_to_cloud_1.isDisplayRequest; } });
var cloud_to_tpa_1 = require("./messages/cloud-to-tpa");
Object.defineProperty(exports, "isTpaConnectionAck", { enumerable: true, get: function () { return cloud_to_tpa_1.isTpaConnectionAck; } });
Object.defineProperty(exports, "isDataStream", { enumerable: true, get: function () { return cloud_to_tpa_1.isDataStream; } });
Object.defineProperty(exports, "isAppStopped", { enumerable: true, get: function () { return cloud_to_tpa_1.isAppStopped; } });
Object.defineProperty(exports, "isSettingsUpdate", { enumerable: true, get: function () { return cloud_to_tpa_1.isSettingsUpdate; } });
// Export setting-related types
var models_1 = require("./models");
Object.defineProperty(exports, "validateTpaConfig", { enumerable: true, get: function () { return models_1.validateTpaConfig; } });
