import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from 'src/types';
/**
 * Extracts the temporary token from a URL string.
 * @param url The URL string, typically window.location.href.
 * @returns The token string or null if not found.
 */
export declare function extractTempToken(url: string): string | null;
/**
 * Exchanges a temporary token for a user ID with the AugmentOS Cloud.
 * This should be called from the TPA's backend server.
 * @param cloudApiUrl The base URL of the AugmentOS Cloud API.
 * @param tempToken The temporary token obtained from the webview URL.
 * @param apiKey Your TPA's secret API key.
 * @returns A Promise that resolves with an object containing the userId.
 * @throws Throws an error if the exchange fails (e.g., invalid token, expired, network error).
 */
export declare function exchangeToken(cloudApiUrl: string, tempToken: string, apiKey: string, packageName: string): Promise<{
    userId: string;
}>;
/**
 * Express middleware for automatically handling the token exchange.
 * Assumes API key and Cloud URL are available (e.g., via environment variables).
 * Adds `req.authUserId` if successful.
 *
 * @param options Configuration options.
 * @param options.cloudApiUrl The base URL of the AugmentOS Cloud API.
 * @param options.apiKey Your TPA's secret API key.
 * @param options.tokenQueryParam The name of the query parameter containing the token (default: 'aos_temp_token').
 * @param options.cookieName The name of the cookie to store the session token (default: 'aos_session').
 * @param options.cookieSecret Secret key used to sign the session cookie. MUST be provided and kept secure.
 * @param options.cookieOptions Options for the session cookie (default: { httpOnly: true, secure: process.env.NODE_ENV === 'production' }).
 */
export declare function createAuthMiddleware(options: {
    apiKey: string;
    packageName: string;
    tokenQueryParam?: string;
    cookieName?: string;
    cookieSecret: string;
    cookieOptions?: {
        httpOnly?: boolean;
        secure?: boolean;
        maxAge?: number;
        sameSite?: boolean | 'lax' | 'strict' | 'none';
        path?: string;
    };
}): (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=index.d.ts.map