import { EventManager, EventData } from './events';
import { LayoutManager } from './layouts';
import { SettingsManager } from './settings';
import { ExtendedStreamType, ButtonPress, HeadPosition, PhoneNotification, TranscriptionData, TranslationData, AppSettings, AppSetting, TpaConfig } from '../../types';
import { DashboardAPI } from '../../types/dashboard';
/**
 * ⚙️ Configuration options for TPA Session
 *
 * @example
 * ```typescript
 * const config: TpaSessionConfig = {
 *   packageName: 'org.example.myapp',
 *   apiKey: 'your_api_key',
 *   // Auto-reconnection is enabled by default
 *   // autoReconnect: true
 * };
 * ```
 */
export interface TpaSessionConfig {
    /** 📦 Unique identifier for your TPA (e.g., 'org.company.appname') */
    packageName: string;
    /** 🔑 API key for authentication with AugmentOS Cloud */
    apiKey: string;
    /** 🔌 WebSocket server URL (default: 'ws://localhost:7002/tpa-ws') */
    augmentOSWebsocketUrl?: string;
    /** 🔄 Automatically attempt to reconnect on disconnect (default: true) */
    autoReconnect?: boolean;
    /** 🔁 Maximum number of reconnection attempts (default: 3) */
    maxReconnectAttempts?: number;
    /** ⏱️ Base delay between reconnection attempts in ms (default: 1000) */
    reconnectDelay?: number;
}
/**
 * 🚀 TPA Session Implementation
 *
 * Manages a live connection between your TPA and AugmentOS Cloud.
 * Provides interfaces for:
 * - 🎮 Event handling (transcription, head position, etc.)
 * - 📱 Display management in AR view
 * - 🔌 Connection lifecycle
 * - 🔄 Automatic reconnection
 *
 * @example
 * ```typescript
 * const session = new TpaSession({
 *   packageName: 'org.example.myapp',
 *   apiKey: 'your_api_key'
 * });
 *
 * // Handle events
 * session.onTranscription((data) => {
 *   session.layouts.showTextWall(data.text);
 * });
 *
 * // Connect to cloud
 * await session.connect('session_123');
 * ```
 */
export declare class TpaSession {
    private config;
    /** WebSocket connection to AugmentOS Cloud */
    private ws;
    /** Current session identifier */
    private sessionId;
    /** Number of reconnection attempts made */
    private reconnectAttempts;
    /** Active event subscriptions */
    private subscriptions;
    /** Resource tracker for automatic cleanup */
    private resources;
    /** Internal settings storage - use public settings API instead */
    private settingsData;
    /** TPA configuration loaded from tpa_config.json */
    private tpaConfig;
    /** Whether to update subscriptions when settings change */
    private shouldUpdateSubscriptionsOnSettingsChange;
    /** Custom subscription handler for settings-based subscriptions */
    private subscriptionSettingsHandler?;
    /** Settings that should trigger subscription updates when changed */
    private subscriptionUpdateTriggers;
    /** Pending photo requests waiting for responses */
    private pendingPhotoRequests;
    /** 🎮 Event management interface */
    readonly events: EventManager;
    /** 📱 Layout management interface */
    readonly layouts: LayoutManager;
    /** ⚙️ Settings management interface */
    readonly settings: SettingsManager;
    /** 📊 Dashboard management interface */
    readonly dashboard: DashboardAPI;
    constructor(config: TpaSessionConfig);
    /**
     * Get the current session ID
     * @returns The current session ID or 'unknown-session-id' if not connected
     */
    getSessionId(): string;
    /**
     * Get the package name for this TPA
     * @returns The package name
     */
    getPackageName(): string;
    /**
     * 🎤 Listen for speech transcription events
     * @param handler - Function to handle transcription data
     * @returns Cleanup function to remove the handler
     */
    onTranscription(handler: (data: TranscriptionData) => void): () => void;
    /**
     * 🌐 Listen for speech transcription events in a specific language
     * @param language - Language code (e.g., "en-US")
     * @param handler - Function to handle transcription data
     * @returns Cleanup function to remove the handler
     * @throws Error if language code is invalid
     */
    onTranscriptionForLanguage(language: string, handler: (data: TranscriptionData) => void): () => void;
    /**
     * 🌐 Listen for speech translation events for a specific language pair
     * @param sourceLanguage - Source language code (e.g., "es-ES")
     * @param targetLanguage - Target language code (e.g., "en-US")
     * @param handler - Function to handle translation data
     * @returns Cleanup function to remove the handler
     * @throws Error if language codes are invalid
     */
    onTranslationForLanguage(sourceLanguage: string, targetLanguage: string, handler: (data: TranslationData) => void): () => void;
    /**
     * 👤 Listen for head position changes
     * @param handler - Function to handle head position updates
     * @returns Cleanup function to remove the handler
     */
    onHeadPosition(handler: (data: HeadPosition) => void): () => void;
    /**
     * 🔘 Listen for hardware button press events
     * @param handler - Function to handle button events
     * @returns Cleanup function to remove the handler
     */
    onButtonPress(handler: (data: ButtonPress) => void): () => void;
    /**
     * 📱 Listen for phone notification events
     * @param handler - Function to handle notifications
     * @returns Cleanup function to remove the handler
     */
    onPhoneNotifications(handler: (data: PhoneNotification) => void): () => void;
    /**
     * 📬 Subscribe to a specific event stream
     * @param type - Type of event to subscribe to
     */
    subscribe(type: ExtendedStreamType): void;
    /**
     * 📭 Unsubscribe from a specific event stream
     * @param type - Type of event to unsubscribe from
     */
    unsubscribe(type: ExtendedStreamType): void;
    /**
     * 🎯 Generic event listener (pub/sub style)
     * @param event - Event name to listen for
     * @param handler - Event handler function
     */
    on<T extends ExtendedStreamType>(event: T, handler: (data: EventData<T>) => void): () => void;
    /**
     * 🚀 Connect to AugmentOS Cloud
     * @param sessionId - Unique session identifier
     * @returns Promise that resolves when connected
     */
    connect(sessionId: string): Promise<void>;
    /**
     * 👋 Disconnect from AugmentOS Cloud
     */
    disconnect(): void;
    /**
     * 📸 Request a photo from the connected glasses
     * @param options - Optional configuration for the photo request
     * @returns Promise that resolves with the URL to the captured photo
     */
    requestPhoto(options?: {
        saveToGallery?: boolean;
    }): Promise<string>;
    /**
     * 🛠️ Get all current user settings
     * @returns A copy of the current settings array
     * @deprecated Use session.settings.getAll() instead
     */
    getSettings(): AppSettings;
    /**
     * 🔍 Get a specific setting value by key
     * @param key The setting key to look for
     * @returns The setting's value, or undefined if not found
     * @deprecated Use session.settings.get(key) instead
     */
    getSetting<T>(key: string): T | undefined;
    /**
     * ⚙️ Configure settings-based subscription updates
     * This allows TPAs to automatically update their subscriptions when certain settings change
     * @param options Configuration options for settings-based subscriptions
     */
    setSubscriptionSettings(options: {
        updateOnChange: string[];
        handler: (settings: AppSettings) => ExtendedStreamType[];
    }): void;
    /**
     * 🔄 Update subscriptions based on current settings
     * Called automatically when relevant settings change
     */
    private updateSubscriptionsFromSettings;
    /**
     * 🧪 For testing: Update settings locally
     * In normal operation, settings come from the cloud
     * @param newSettings The new settings to apply
     */
    updateSettingsForTesting(newSettings: AppSettings): void;
    /**
     * 📝 Load configuration from a JSON file
     * @param jsonData JSON string containing TPA configuration
     * @returns The loaded configuration
     * @throws Error if the configuration is invalid
     */
    loadConfigFromJson(jsonData: string): TpaConfig;
    /**
     * 📋 Get the loaded TPA configuration
     * @returns The current TPA configuration or null if not loaded
     */
    getConfig(): TpaConfig | null;
    /**
     * 🔌 Get the WebSocket server URL for this session
     * @returns The WebSocket server URL used by this session
     */
    getServerUrl(): string | undefined;
    /**
     * 🔍 Get default settings from the TPA configuration
     * @returns Array of settings with default values
     * @throws Error if configuration is not loaded
     */
    getDefaultSettings(): AppSettings;
    /**
     * 🔍 Get setting schema from configuration
     * @param key Setting key to look up
     * @returns The setting schema or undefined if not found
     */
    getSettingSchema(key: string): AppSetting | undefined;
    /**
     * 📨 Handle incoming messages from cloud
     */
    private handleMessage;
    /**
     * 🧪 Validate incoming message structure
     * @param message - Message to validate
     * @returns boolean indicating if the message is valid
     */
    private validateMessage;
    /**
     * 📦 Handle binary message data (audio or video)
     * @param buffer - Binary data as ArrayBuffer
     */
    private handleBinaryMessage;
    /**
     * 🧹 Sanitize event data to prevent crashes from malformed data
     * @param streamType - The type of stream data
     * @param data - The potentially unsafe data to sanitize
     * @returns Sanitized data safe for processing
     */
    private sanitizeEventData;
    /**
     * 🔐 Send connection initialization message
     */
    private sendConnectionInit;
    /**
     * 📝 Update subscription list with cloud
     */
    private updateSubscriptions;
    /**
     * 🔄 Handle reconnection with exponential backoff
     */
    private handleReconnection;
    /**
     * 📤 Send message to cloud with validation and error handling
     * @throws {Error} If WebSocket is not connected
     */
    private send;
}
//# sourceMappingURL=index.d.ts.map