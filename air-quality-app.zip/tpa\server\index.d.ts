/**
 * 🚀 TPA Server Module
 *
 * Creates and manages a server for Third Party Apps (TPAs) in the AugmentOS ecosystem.
 * Handles webhook endpoints, session management, and cleanup.
 */
import { type Express } from 'express';
import { TpaSession } from '../session';
import { ToolCall } from '../../types';
/**
 * 🔧 Configuration options for TPA Server
 *
 * @example
 * ```typescript
 * const config: TpaServerConfig = {
 *   packageName: 'org.example.myapp',
 *   apiKey: 'your_api_key',
 *   port: 7010,
 *   publicDir: './public'
 * };
 * ```
 */
export interface TpaServerConfig {
    /** 📦 Unique identifier for your TPA (e.g., 'org.company.appname') must match what you specified at https://console.augmentos.org */
    packageName: string;
    /** 🔑 API key for authentication with AugmentOS Cloud */
    apiKey: string;
    /** 🌐 Port number for the server (default: 7010) */
    port?: number;
    /** 🛣️ [DEPRECATED] do not set: The SDK will automatically expose an endpoint at '/webhook' */
    webhookPath?: string;
    /**
     * 📂 Directory for serving static files (e.g., images, logos)
     * Set to false to disable static file serving
     */
    publicDir?: string | false;
    /** 🔌 [DEPRECATED] No need to set this value */
    augmentOSWebsocketUrl?: string;
    /** ❤️ Enable health check endpoint at /health (default: true) */
    healthCheck?: boolean;
    /**
     * 🔐 Secret key used to sign session cookies
     * This must be a strong, unique secret
     */
    cookieSecret?: string;
}
/**
 * 🎯 TPA Server Implementation
 *
 * Base class for creating TPA servers. Handles:
 * - 🔄 Session lifecycle management
 * - 📡 Webhook endpoints for AugmentOS Cloud
 * - 📂 Static file serving
 * - ❤️ Health checks
 * - 🧹 Cleanup on shutdown
 *
 * @example
 * ```typescript
 * class MyAppServer extends TpaServer {
 *   protected async onSession(session: TpaSession, sessionId: string, userId: string) {
 *     // Handle new user sessions here
 *     session.events.onTranscription((data) => {
 *       session.layouts.showTextWall(data.text);
 *     });
 *   }
 * }
 *
 * const server = new MyAppServer({
 *   packageName: 'org.example.myapp',
 *   apiKey: 'your_api_key',
 *   publicDir: "/public",
 * });
 *
 * await server.start();
 * ```
 */
export declare class TpaServer {
    private config;
    /** Express app instance */
    private app;
    /** Map of active user sessions by sessionId */
    private activeSessions;
    /** Array of cleanup handlers to run on shutdown */
    private cleanupHandlers;
    constructor(config: TpaServerConfig);
    getExpressApp(): Express;
    /**
     * 👥 Session Handler
     * Override this method to handle new TPA sessions.
     * This is where you implement your app's core functionality.
     *
     * @param session - TPA session instance for the user
     * @param sessionId - Unique identifier for this session
     * @param userId - User's identifier
     */
    protected onSession(session: TpaSession, sessionId: string, userId: string): Promise<void>;
    /**
     * 👥 Stop Handler
     * Override this method to handle stop requests.
     * This is where you can clean up resources when a session is stopped.
     *
     * @param sessionId - Unique identifier for this session
     * @param userId - User's identifier
     * @param reason - Reason for stopping
     */
    protected onStop(sessionId: string, userId: string, reason: string): Promise<void>;
    /**
     * 🛠️ Tool Call Handler
     * Override this method to handle tool calls from AugmentOS Cloud.
     * This is where you implement your app's tool functionality.
     *
     * @param toolCall - The tool call request containing tool details and parameters
     * @returns Optional string response that will be sent back to AugmentOS Cloud
     */
    protected onToolCall(toolCall: ToolCall): Promise<string | undefined>;
    /**
     * 🚀 Start the Server
     * Starts listening for incoming connections and webhook calls.
     *
     * @returns Promise that resolves when server is ready
     */
    start(): Promise<void>;
    /**
     * 🛑 Stop the Server
     * Gracefully shuts down the server and cleans up all sessions.
     */
    stop(): void;
    /**
   * 🔐 Generate a TPA token for a user
   * This should be called when handling a session webhook request.
   *
   * @param userId - User identifier
   * @param sessionId - Session identifier
   * @param secretKey - Secret key for signing the token
   * @returns JWT token string
   */
    protected generateToken(userId: string, sessionId: string, secretKey: string): string;
    /**
     * 🧹 Add Cleanup Handler
     * Register a function to be called during server shutdown.
     *
     * @param handler - Function to call during cleanup
     */
    protected addCleanupHandler(handler: () => void): void;
    /**
     * 🎯 Setup Webhook Endpoint
     * Creates the webhook endpoint that AugmentOS Cloud calls to start new sessions.
     */
    private setupWebhook;
    /**
     * 🛠️ Setup Tool Call Endpoint
     * Creates a /tool endpoint for handling tool calls from AugmentOS Cloud.
     */
    private setupToolCallEndpoint;
    /**
     * Handle a session request webhook
     */
    private handleSessionRequest;
    /**
     * Handle a stop request webhook
     */
    private handleStopRequest;
    /**
     * ❤️ Setup Health Check Endpoint
     * Creates a /health endpoint for monitoring server status.
     */
    private setupHealthCheck;
    /**
     * ⚙️ Setup Settings Endpoint
     * Creates a /settings endpoint that the AugmentOS Cloud can use to update settings.
     */
    private setupSettingsEndpoint;
    /**
     * 📂 Setup Static File Serving
     * Configures Express to serve static files from the specified directory.
     */
    private setupPublicDir;
    /**
     * 🛑 Setup Shutdown Handlers
     * Registers process signal handlers for graceful shutdown.
     */
    private setupShutdown;
    /**
     * 🧹 Cleanup
     * Closes all active sessions and runs cleanup handlers.
     */
    private cleanup;
}
//# sourceMappingURL=index.d.ts.map