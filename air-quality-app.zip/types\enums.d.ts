/**
 * Types of Third-Party Applications (TPAs)
 */
export declare enum TpaType {
    SYSTEM_DASHBOARD = "system_dashboard",// Special UI placement, system functionality
    BACKGROUND = "background",// Can temporarily take control of display
    STANDARD = "standard"
}
/**
 * Application states in the system
 */
export declare enum AppState {
    NOT_INSTALLED = "not_installed",// Initial state
    INSTALLED = "installed",// Installed but never run
    BOOTING = "booting",// Starting up
    RUNNING = "running",// Active and running
    STOPPED = "stopped",// Manually stopped
    ERROR = "error"
}
/**
 * Supported languages
 */
export declare enum Language {
    EN = "en",
    ES = "es",
    FR = "fr"
}
/**
 * Types of layouts for displaying content
 */
export declare enum LayoutType {
    TEXT_WALL = "text_wall",
    DOUBLE_TEXT_WALL = "double_text_wall",
    DASHBOARD_CARD = "dashboard_card",
    REFERENCE_CARD = "reference_card",
    BITMAP_VIEW = "bitmap_view"
}
/**
 * Types of views for displaying content
 */
export declare enum ViewType {
    DASHBOARD = "dashboard",// Regular dashboard (main/expanded)
    ALWAYS_ON = "always_on",// Persistent overlay dashboard
    MAIN = "main"
}
export declare enum AppSettingType {
    TOGGLE = "toggle",
    TEXT = "text",
    SELECT = "select"
}
//# sourceMappingURL=enums.d.ts.map