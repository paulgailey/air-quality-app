import { BaseMessage } from './base';
import { CloudToTpaMessageType } from '../message-types';
import { StreamType } from '../streams';
import { AppSettings, TpaConfig } from '../models';
import { LocationUpdate, CalendarEvent } from './glasses-to-cloud';
import { DashboardMode } from '../dashboard';
/**
 * Connection acknowledgment to TPA
 */
export interface TpaConnectionAck extends BaseMessage {
    type: CloudToTpaMessageType.CONNECTION_ACK;
    settings?: AppSettings;
    config?: TpaConfig;
}
/**
 * Connection error to TPA
 */
export interface TpaConnectionError extends BaseMessage {
    type: CloudToTpaMessageType.CONNECTION_ERROR;
    message: string;
    code?: string;
}
/**
 * App stopped notification to TPA
 */
export interface AppStopped extends BaseMessage {
    type: CloudToTpaMessageType.APP_STOPPED;
    reason: "user_disabled" | "system_stop" | "error";
    message?: string;
}
/**
 * Settings update to TPA
 */
export interface SettingsUpdate extends BaseMessage {
    type: CloudToTpaMessageType.SETTINGS_UPDATE;
    packageName: string;
    settings: AppSettings;
}
/**
 * AugmentOS settings update to TPA
 */
export interface AugmentosSettingsUpdate extends BaseMessage {
    type: 'augmentos_settings_update';
    sessionId: string;
    settings: Record<string, any>;
    timestamp: Date;
}
/**
 * Transcription data
 */
export interface TranscriptionData extends BaseMessage {
    type: StreamType.TRANSCRIPTION;
    text: string;
    isFinal: boolean;
    transcribeLanguage?: string;
    startTime: number;
    endTime: number;
    speakerId?: string;
    duration?: number;
}
/**
 * Translation data
 */
export interface TranslationData extends BaseMessage {
    type: StreamType.TRANSLATION;
    text: string;
    originalText?: string;
    isFinal: boolean;
    startTime: number;
    endTime: number;
    speakerId?: string;
    duration?: number;
    transcribeLanguage?: string;
    translateLanguage?: string;
    didTranslate?: boolean;
}
/**
 * Audio chunk data
 */
export interface AudioChunk extends BaseMessage {
    type: StreamType.AUDIO_CHUNK;
    arrayBuffer: ArrayBufferLike;
    sampleRate?: number;
}
/**
 * Tool call from cloud to TPA
 * Represents a tool invocation with filled parameters
 */
export interface ToolCall {
    toolId: string;
    toolParameters: Record<string, string | number | boolean>;
    timestamp: Date;
    userId: string;
}
/**
 * Stream data to TPA
 */
export interface DataStream extends BaseMessage {
    type: CloudToTpaMessageType.DATA_STREAM;
    streamType: StreamType;
    data: unknown;
}
/**
 * Dashboard mode changed notification
 */
export interface DashboardModeChanged extends BaseMessage {
    type: CloudToTpaMessageType.DASHBOARD_MODE_CHANGED;
    mode: DashboardMode;
}
/**
 * Dashboard always-on state changed notification
 */
export interface DashboardAlwaysOnChanged extends BaseMessage {
    type: CloudToTpaMessageType.DASHBOARD_ALWAYS_ON_CHANGED;
    enabled: boolean;
}
/**
 * Photo response to TPA
 */
export interface PhotoResponse extends BaseMessage {
    type: CloudToTpaMessageType.PHOTO_RESPONSE;
    photoUrl: string;
    requestId: string;
}
/**
 * Video stream response to TPA
 */
export interface VideoStreamResponse extends BaseMessage {
    type: CloudToTpaMessageType.VIDEO_STREAM_RESPONSE;
    streamUrl: string;
    appId: string;
}
/**
 * Standard connection error (for server compatibility)
 */
export interface StandardConnectionError extends BaseMessage {
    type: 'connection_error';
    message: string;
}
/**
 * Custom message for general-purpose communication (cloud to TPA)
 */
export interface CustomMessage extends BaseMessage {
    type: CloudToTpaMessageType.CUSTOM_MESSAGE;
    action: string;
    payload: any;
}
/**
 * Union type for all messages from cloud to TPAs
 */
export type CloudToTpaMessage = TpaConnectionAck | TpaConnectionError | StandardConnectionError | AppStopped | SettingsUpdate | TranscriptionData | TranslationData | AudioChunk | LocationUpdate | CalendarEvent | DataStream | PhotoResponse | VideoStreamResponse | DashboardModeChanged | DashboardAlwaysOnChanged | AugmentosSettingsUpdate | CustomMessage;
export declare function isTpaConnectionAck(message: CloudToTpaMessage): message is TpaConnectionAck;
export declare function isTpaConnectionError(message: CloudToTpaMessage): message is TpaConnectionError;
export declare function isAppStopped(message: CloudToTpaMessage): message is AppStopped;
export declare function isSettingsUpdate(message: CloudToTpaMessage): message is SettingsUpdate;
export declare function isDataStream(message: CloudToTpaMessage): message is DataStream;
export declare function isAudioChunk(message: CloudToTpaMessage): message is AudioChunk;
export declare function isPhotoResponse(message: CloudToTpaMessage): message is PhotoResponse;
export declare function isVideoStreamResponse(message: CloudToTpaMessage): message is VideoStreamResponse;
export declare function isDashboardModeChanged(message: CloudToTpaMessage): message is DashboardModeChanged;
export declare function isDashboardAlwaysOnChanged(message: CloudToTpaMessage): message is DashboardAlwaysOnChanged;
//# sourceMappingURL=cloud-to-tpa.d.ts.map