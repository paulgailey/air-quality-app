"use strict";
// src/messages/cloud-to-tpa.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTpaConnectionAck = isTpaConnectionAck;
exports.isTpaConnectionError = isTpaConnectionError;
exports.isAppStopped = isAppStopped;
exports.isSettingsUpdate = isSettingsUpdate;
exports.isDataStream = isDataStream;
exports.isAudioChunk = isAudioChunk;
exports.isPhotoResponse = isPhotoResponse;
exports.isVideoStreamResponse = isVideoStreamResponse;
exports.isDashboardModeChanged = isDashboardModeChanged;
exports.isDashboardAlwaysOnChanged = isDashboardAlwaysOnChanged;
const message_types_1 = require("../message-types");
const streams_1 = require("../streams");
//===========================================================
// Type guards
//===========================================================
function isTpaConnectionAck(message) {
    return message.type === message_types_1.CloudToTpaMessageType.CONNECTION_ACK;
}
function isTpaConnectionError(message) {
    return message.type === message_types_1.CloudToTpaMessageType.CONNECTION_ERROR || message.type === 'connection_error';
}
function isAppStopped(message) {
    return message.type === message_types_1.CloudToTpaMessageType.APP_STOPPED;
}
function isSettingsUpdate(message) {
    return message.type === message_types_1.CloudToTpaMessageType.SETTINGS_UPDATE;
}
function isDataStream(message) {
    return message.type === message_types_1.CloudToTpaMessageType.DATA_STREAM || message.type === streams_1.StreamType.AUDIO_CHUNK;
}
function isAudioChunk(message) {
    return message.type === streams_1.StreamType.AUDIO_CHUNK;
}
function isPhotoResponse(message) {
    return message.type === message_types_1.CloudToTpaMessageType.PHOTO_RESPONSE;
}
function isVideoStreamResponse(message) {
    return message.type === message_types_1.CloudToTpaMessageType.VIDEO_STREAM_RESPONSE;
}
function isDashboardModeChanged(message) {
    return message.type === message_types_1.CloudToTpaMessageType.DASHBOARD_MODE_CHANGED;
}
function isDashboardAlwaysOnChanged(message) {
    return message.type === message_types_1.CloudToTpaMessageType.DASHBOARD_ALWAYS_ON_CHANGED;
}
