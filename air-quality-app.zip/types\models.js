"use strict";
// @augmentos/sdk
// packages/sdk/types/src/models.ts - Core models
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionType = void 0;
exports.validateTpaConfig = validateTpaConfig;
const enums_1 = require("./enums");
// Define PermissionType enum until it's added to the SDK
var PermissionType;
(function (PermissionType) {
    PermissionType["MICROPHONE"] = "MICROPHONE";
    PermissionType["LOCATION"] = "LOCATION";
    PermissionType["CALENDAR"] = "CALENDAR";
    PermissionType["NOTIFICATIONS"] = "NOTIFICATIONS";
    PermissionType["ALL"] = "ALL";
})(PermissionType || (exports.PermissionType = PermissionType = {}));
/**
 * Validate a TPA configuration object
 * @param config Object to validate
 * @returns True if the config is valid
 */
function validateTpaConfig(config) {
    if (!config || typeof config !== 'object')
        return false;
    // Check required string properties
    if (typeof config.name !== 'string' ||
        typeof config.description !== 'string' ||
        typeof config.version !== 'string') {
        return false;
    }
    // Check settings array
    if (!Array.isArray(config.settings))
        return false;
    // Validate each setting
    return config.settings.every((setting) => {
        // Group settings just need a title
        if (setting.type === 'group') {
            return typeof setting.title === 'string';
        }
        // Regular settings need key and label
        if (typeof setting.key !== 'string' || typeof setting.label !== 'string') {
            return false;
        }
        // Type-specific validation
        switch (setting.type) {
            case enums_1.AppSettingType.TOGGLE:
                return typeof setting.defaultValue === 'boolean';
            case enums_1.AppSettingType.TEXT:
                return setting.defaultValue === undefined || typeof setting.defaultValue === 'string';
            case enums_1.AppSettingType.SELECT:
                return Array.isArray(setting.options) &&
                    setting.options.every((opt) => typeof opt.label === 'string' && 'value' in opt);
            default:
                return false;
        }
    });
}
